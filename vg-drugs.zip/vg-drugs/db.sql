CREATE TABLE IF NOT EXISTS `vg_drug_props` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(64) NOT NULL,
  `type` varchar(50) NOT NULL,
  `bucket` int(11) NOT NULL DEFAULT 0,
  `caravan_id` varchar(20) DEFAULT NULL,
  `coords` longtext NOT NULL,
  `data` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vg_drug_props_owner` (`owner`),
  KEY `idx_vg_drug_props_type` (`type`),
  KEY `idx_vg_drug_props_bucket` (`bucket`),
  KEY `idx_vg_drug_props_caravan` (`caravan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vg_drug_lab_vehicles` (
  `plate` varchar(20) NOT NULL,
  `lab_type` varchar(16) NOT NULL DEFAULT 'meth',
  `updated_by` varchar(64) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vg_drug_lab_props` (
  `plate` varchar(20) NOT NULL,
  `props` longtext DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vg_drug_lab_props_v2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate` varchar(20) NOT NULL,
  `model` varchar(100) NOT NULL,
  `prop_type` varchar(50) NOT NULL,
  `offset_coords` longtext NOT NULL,
  `heading_offset` float NOT NULL DEFAULT 0,
  `item_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vg_drug_lab_props_v2_plate` (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;