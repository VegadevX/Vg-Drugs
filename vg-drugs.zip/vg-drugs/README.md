# VG Drugs

See `install/README.md` for the full English installation guide.
