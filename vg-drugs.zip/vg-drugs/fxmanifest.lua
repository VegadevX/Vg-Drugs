fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'VG / OpenAI'
description 'Advanced prop-based drug system with weed, coke, meth, and caravan labs'
version '1.6.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'shared/locale.lua'
}

client_scripts {
    'client/weed.lua',
    'client/coke.lua',
    'client/meth.lua',
    'client/sell.lua',
    'client/shops.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/weed.lua',
    'server/coke.lua',
    'server/meth.lua',
    'server/sell.lua',
    'server/shops.lua'
}

dependencies {
    'ox_lib',
    'ox_target',
    'ox_inventory'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/lang.js',
    'html/bottle.png',
    'html/pot.png'
}