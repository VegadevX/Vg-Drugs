# VG Drugs Compatibility Update

## What changed

- Added framework bridge: `server/bridge/framework.lua`.
- Added client integration bridge: `client/bridge/framework.lua`.
- `Config.Framework`, `Config.Inventory`, and `Config.Target` now support `auto` mode.
- Supported frameworks: QB-Core, QBox/QBX, ESX, and standalone fallback.
- Supported inventories: ox_inventory, qb-inventory style inventories, ps-inventory, lj-inventory, qs-inventory, and custom hooks.
- Supported targets: ox_target, qb-target, qtarget, and custom hooks.
- Weed and coke production now asks the player how many items to produce in one action.
- Meth production already had batch input and now uses the shared inventory bridge.
- Multi-language system was extended with missing batch-production, shop, and sale texts.
- Config comments were added in English and custom integration hooks were added at the bottom of `config.lua`.

## Recommended config

```lua
Config.Framework = 'auto'
Config.Inventory = 'auto'
Config.Target = 'auto'
Config.Locale = 'en' -- en/tr/es/fr
```

## Custom inventory or target

If your server uses a private inventory/target system, set:

```lua
Config.Inventory = 'custom'
Config.Target = 'custom'
```

Then fill `Config.CustomInventory` and/or `Config.CustomTarget` in `config.lua`.

## Notes

- `ox_lib` is still required.
- `oxmysql` is still used by the existing database/prop persistence logic.
- For stash opening, ox_inventory is supported directly. Other inventories should be connected through the custom hook/client event used by your phone/server inventory.

## Batch production limits

Batch production amounts are controlled from `Config.BatchProduction` in `config.lua`.

Each entry uses this format:

```lua
key = { min = 1, max = 25 }
```

The client input will only allow values inside the configured range, and the server validates the same range again before giving/removing items.

Available keys:

- `weed_pack`
- `weed_joint`
- `coke_process`
- `coke_pack`
- `meth_cook`
- `meth_pack_10g`
- `meth_pack_1kg`
