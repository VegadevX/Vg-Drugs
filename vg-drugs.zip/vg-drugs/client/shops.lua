local spawnedPeds = {}

CreateThread(function()
    for shopKey, data in pairs(Config.DrugShops) do
        lib.requestModel(data.pedModel)

        local ped = CreatePed(0, GetHashKey(data.pedModel), data.coords.x, data.coords.y, data.coords.z - 1.0, data.coords.w, false, false)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)

        spawnedPeds[shopKey] = ped

        exports.ox_target:addLocalEntity(ped, {
            {
                name = 'drug_shop_' .. shopKey,
                icon = 'fas fa-shopping-cart',
                label = _L('target_talk_supplier'),
                onSelect = function()
                    OpenDrugShop(shopKey)
                end
            }
        })
    end
end)

function OpenDrugShop(shopKey)
    local shop = Config.DrugShops[shopKey]
    local options = {}

    for k, v in ipairs(shop.items) do
        table.insert(options, {
            title = v.label,
            description = 'Fiyat: $' .. v.price,
            icon = 'box',
            onSelect = function()
                local input = lib.inputDialog('Buy: ' .. v.label, {
                    { type = 'number', label = 'How many do you want to buy?', default = 1, min = 1 }
                })

                if not input or not input[1] then return end

                TriggerServerEvent('vg-drugs:server:BuyDrugItem', shopKey, k, input[1])
            end
        })
    end

    lib.registerContext({
        id = 'drug_shop_menu_' .. shopKey,
        title = 'Dark Supplier',
        options = options
    })
    lib.showContext('drug_shop_menu_' .. shopKey)
end
