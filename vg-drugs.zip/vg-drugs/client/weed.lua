local placingProp = false
local currentProp = nil
local SpawnedProps = {}

local WEED_MODELS = {
    [`bkr_prop_weed_bucket_01a`] = true,
    [`bkr_prop_weed_bucket_open_01a`] = true,
    [`bkr_prop_weed_bucket_open_01b`] = true,
    [`prop_plant_pot_02a`] = true,
    [`prop_plant_pot_03a`] = true,
    [`bkr_prop_weed_01_small_01b`] = true,
    [`bkr_prop_weed_med_01a`] = true,
    [`bkr_prop_weed_lrg_01b`] = true,
    [`prop_worklight_03b`] = true,
    [`bkr_prop_weed_table_01a`] = true,
    [`prop_pot_plant_01b`] = true,
}

local function requestValidModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then
        return nil
    end
    lib.requestModel(hash)
    return hash
end

local function rotationToDirection(rot)
    local rotZ = math.rad(rot.z)
    local rotX = math.rad(rot.x)
    local cosX = math.abs(math.cos(rotX))
    return vec3(-math.sin(rotZ) * cosX, math.cos(rotZ) * cosX, math.sin(rotX))
end

local function raycastFromCamera(distance)
    local camCoord = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local direction = rotationToDirection(camRot)
    local destination = camCoord + (direction * distance)
    local ray = StartShapeTestRay(
        camCoord.x, camCoord.y, camCoord.z,
        destination.x, destination.y, destination.z,
        -1, cache.ped, 0
    )
    local _, hit, endCoords, surfaceNormal, entityHit = GetShapeTestResult(ray)
    return hit == 1, endCoords, surfaceNormal, entityHit
end

local function getPlacementPoint(distance)
    local hit, hitCoords, normal = raycastFromCamera(distance or 5.0)
    if hit and hitCoords then
        return vec3(hitCoords.x, hitCoords.y, hitCoords.z), vec3(normal.x, normal.y, normal.z), true
    end

    local coords = GetOffsetFromEntityInWorldCoords(cache.ped, 0.0, 1.25, 0.0)
    local _, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + 2.0, false)
    return vec3(coords.x, coords.y, groundZ), vec3(0.0, 0.0, 1.0), false
end

local function clearSpawnedProp(id)
    local prop = SpawnedProps[id]
    if not prop then return end

    if prop.base and DoesEntityExist(prop.base) then
        VG.Target.RemoveLocalEntity(prop.base)
        DeleteEntity(prop.base)
    end

    SpawnedProps[id] = nil
end

local function clearAllSpawnedProps()
    for id in pairs(SpawnedProps) do
        clearSpawnedProp(id)
    end
end

local function cleanupNearbyObjects(coords)
    if not coords then return end
    local objects = GetGamePool('CObject')

    for i = 1, #objects do
        local obj = objects[i]
        if DoesEntityExist(obj) then
            local model = GetEntityModel(obj)
            if WEED_MODELS[model] and #(GetEntityCoords(obj) - vec3(coords.x, coords.y, coords.z)) < 0.85 then
                SetEntityAsMissionEntity(obj, true, true)
                DeleteEntity(obj)
            end
        end
    end
end

local function getPlantModelForStage(stage)
    if not stage or stage == 0 then return Config.Weed.Props.pot end
    if stage == 1 then return Config.Weed.Props.stage1 end
    if stage == 2 then return Config.Weed.Props.stage2 end
    if stage >= 3 then return Config.Weed.Props.stage3 end
    return Config.Weed.Props.pot
end

local function isLightNearby(coords)
    for _, prop in pairs(SpawnedProps) do
        if prop.type == 'grow_light' then
            local dist = #(vec3(prop.coords.x, prop.coords.y, prop.coords.z) - vec3(coords.x, coords.y, coords.z))
            if dist < 15.0 then
                return true
            end
        end
    end
    return false
end

local function startPlacement(model, propType, itemName)
    if placingProp then return end
    placingProp = true

    local hash = requestValidModel(model)
    if not hash then
        placingProp = false
        return lib.notify({ type = 'error', description = _L('invalid_model', tostring(model)) })
    end

    currentProp = CreateObjectNoOffset(hash, 0.0, 0.0, 0.0, false, false, false)
    SetEntityAlpha(currentProp, 170, false)
    SetEntityCollision(currentProp, false, false)
    FreezeEntityPosition(currentProp, true)

    local minDim = vec3(0.0, 0.0, 0.0)
    do
        local a, b = GetModelDimensions(hash)
        minDim = a
    end

    local heading = GetEntityHeading(cache.ped)
    lib.showTextUI(_L('place_controls'), { position = 'right-center', icon = 'hand' })

    CreateThread(function()
        while placingProp do
            Wait(0)

            local coords, normal = getPlacementPoint(5.0)
            local zOffset = math.abs(minDim.z)
            local finalCoords = vec3(
                coords.x,
                coords.y,
                coords.z + zOffset + (normal.z > 0.75 and 0.01 or 0.0)
            )

            SetEntityCoordsNoOffset(currentProp, finalCoords.x, finalCoords.y, finalCoords.z, false, false, false)
            SetEntityHeading(currentProp, heading)

            if IsControlPressed(0, 14) then heading = heading + 2.0 end
            if IsControlPressed(0, 15) then heading = heading - 2.0 end

            if IsControlJustPressed(0, 38) then
                placingProp = false
                lib.hideTextUI()
                DeleteEntity(currentProp)

                TriggerServerEvent(
                    'vg-drugs:server:SaveProp',
                    model,
                    propType,
                    { x = finalCoords.x, y = finalCoords.y, z = finalCoords.z },
                    heading,
                    itemName
                )
                break
            elseif IsControlJustPressed(0, 177) then
                placingProp = false
                lib.hideTextUI()
                DeleteEntity(currentProp)
                break
            end
        end
    end)
end

local function openPlantStatus(id)
    local values = lib.callback.await('vg-drugs:server:GetPlantStatus', false, id)
    if not values then
        return lib.notify({ type = 'error', description = _L('generic_error') or 'Status could not be retrieved.' })
    end

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'openPlantStatus',
        locale = Config.Locale or 'tr',
        values = values
    })
end

local function buildWeedPotOptions(id)
    return {
        {
            name = ('weed_fertilize_%s'):format(id),
            icon = 'fas fa-mound',
            label = _L('target_fertilize_soil'),
            canInteract = function()
                return SpawnedProps[id] and not SpawnedProps[id].data.fertilized
            end,
            onSelect = function()
                TriggerEvent('vg-drugs:client:InteractPot', id, 'fertilize')
            end
        },
        {
            name = ('weed_plant_%s'):format(id),
            icon = 'fas fa-seedling',
            label = _L('target_add_seed'),
            canInteract = function()
                return SpawnedProps[id] and SpawnedProps[id].data.fertilized and not SpawnedProps[id].data.planted
            end,
            onSelect = function()
                TriggerEvent('vg-drugs:client:InteractPot', id, 'plant')
            end
        },
        {
            name = ('weed_water_%s'):format(id),
            icon = 'fas fa-droplet',
            label = _L('target_water'),
            canInteract = function()
                return SpawnedProps[id] and SpawnedProps[id].data.planted and (SpawnedProps[id].data.stage or 0) < 3
            end,
            onSelect = function()
                TriggerEvent('vg-drugs:client:InteractPot', id, 'water')
            end
        },
        {
            name = ('weed_status_%s'):format(id),
            icon = 'fas fa-chart-simple',
            label = _L('target_view_status'),
            canInteract = function()
                return SpawnedProps[id] ~= nil
            end,
            onSelect = function()
                openPlantStatus(id)
            end
        },
        {
            name = ('weed_harvest_%s'):format(id),
            icon = 'fas fa-leaf',
            label = _L('target_harvest'),
            canInteract = function()
                return SpawnedProps[id] and (SpawnedProps[id].data.stage or 0) >= 3
            end,
            onSelect = function()
                TriggerEvent('vg-drugs:client:InteractPot', id, 'harvest')
            end
        },
        {
            name = ('weed_pickup_%s'):format(id),
            icon = 'fas fa-hand',
            label = _L('target_pickup_pot'),
            canInteract = function()
                return SpawnedProps[id] and not SpawnedProps[id].data.planted
            end,
            onSelect = function()
                TriggerServerEvent('vg-drugs:server:PickupProp', id, 'weed_pot')
            end
        },
        {
            name = ('weed_destroy_%s'):format(id),
            icon = 'fas fa-trash-alt',
            label = _L('target_destroy_plant'),
            canInteract = function()
                return SpawnedProps[id] ~= nil
            end,
            onSelect = function()
                local alert = lib.alertDialog({
                    header = _L('destroy_plant_header') or 'Destroy Plant',
                    content = _L('destroy_plant_content') or 'This action cannot be undone. The plant and pot will be deleted permanently.',
                    centered = true,
                    cancel = true
                })

                if alert == 'confirm' then
                    TriggerServerEvent('vg-drugs:server:DestroyWeedPlant', id)
                end
            end
        }
    }
end

local function buildPropOptions(id, propType)
    if propType == 'weed_table' then
        return {
            {
                name = ('weed_pack_%s'):format(id),
                icon = 'fas fa-box',
                label = _L('target_pack'),
                onSelect = function()
                    TriggerEvent('vg-drugs:client:ProcessWeed', 'pack')
                end
            },
            {
                name = ('weed_joint_%s'):format(id),
                icon = 'fas fa-joint',
                label = _L('target_roll_joint'),
                onSelect = function()
                    TriggerEvent('vg-drugs:client:ProcessWeed', 'joint')
                end
            },
            {
                name = ('weed_table_pickup_%s'):format(id),
                icon = 'fas fa-hand',
                label = _L('target_pickup_table'),
                onSelect = function()
                    TriggerServerEvent('vg-drugs:server:PickupProp', id, 'weed_table')
                end
            },
        }
    elseif propType == 'weed_pot' then
        return buildWeedPotOptions(id)
    elseif propType == 'grow_light' then
        return {
            {
                name = ('light_pickup_%s'):format(id),
                icon = 'fas fa-hand',
                label = _L('target_pickup_light'),
                onSelect = function()
                    TriggerServerEvent('vg-drugs:server:PickupProp', id, 'grow_light')
                end
            },
        }
    elseif propType == 'coke_table' then
        return {
            {
                name = ('coke_pickup_%s'):format(id),
                icon = 'fas fa-hand',
                label = _L('target_pickup_table'),
                onSelect = function()
                    TriggerServerEvent('vg-drugs:server:PickupProp', id, 'coke_table')
                end
            },
        }
    elseif propType == 'meth_table' then
        return {
            {
                name = ('meth_pickup_%s'):format(id),
                icon = 'fas fa-hand',
                label = _L('target_pickup_table'),
                onSelect = function()
                    TriggerServerEvent('vg-drugs:server:PickupProp', id, 'meth_table')
                end
            },
        }
    end

    return {}
end

RegisterNetEvent('vg-drugs:client:UseItem', function(data)
    if data.type == 'weed_table' then
        startPlacement(Config.Weed.Props.table, 'weed_table', Config.Weed.Items.table)
    elseif data.type == 'pot' then
        startPlacement(Config.Weed.Props.pot, 'weed_pot', Config.Weed.Items.pot)
    elseif data.type == 'light' then
        startPlacement(Config.Weed.Props.light, 'grow_light', Config.Weed.Items.light)
    end
end)

RegisterNetEvent('vg-drugs:client:SpawnProp', function(id, model, propType, coords, heading, data)
    clearSpawnedProp(id)
    cleanupNearbyObjects(coords)

    local propData = data or {}
    local hash = requestValidModel(model)

    if propType == 'weed_pot' then
        hash = requestValidModel(getPlantModelForStage(propData.stage or 0))
    end

    if not hash then return end

    local base = CreateObjectNoOffset(hash, coords.x, coords.y, coords.z, false, false, false)
    SetEntityHeading(base, heading or 0.0)
    FreezeEntityPosition(base, true)
    SetEntityAsMissionEntity(base, true, true)

    SpawnedProps[id] = {
        base = base,
        plant = nil,
        type = propType,
        coords = coords,
        heading = heading or 0.0,
        data = propData
    }

    VG.Target.AddLocalEntity(base, buildPropOptions(id, propType))
end)

RegisterNetEvent('vg-drugs:client:RemoveProp', function(id)
    clearSpawnedProp(id)
end)

RegisterNetEvent('vg-drugs:client:RemoveAllProps', function()
    clearAllSpawnedProps()
end)

RegisterNetEvent('vg-drugs:client:UpdateProp', function(id, newData)
    local prop = SpawnedProps[id]
    if not prop then return end

    TriggerEvent(
        'vg-drugs:client:SpawnProp',
        id,
        GetEntityModel(prop.base),
        prop.type,
        prop.coords,
        prop.heading,
        newData or {}
    )
end)

RegisterNetEvent('vg-drugs:client:InteractPot', function(id, action)
    if action == 'fertilize' then
        if (VG.Inventory.Count(Config.Weed.Items.fertilizer) or 0) < 1 then
            return lib.notify({ type = 'error', description = _L('no_fertilizer') or 'You do not have fertilizer.' })
        end

        if lib.progressCircle({
            duration = 4000,
            position = 'bottom',
            label = _L('fertilizing') or 'Applying fertilizer...',
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'amb@world_human_gardener_plant@male@base', clip = 'base' }
        }) then
            TriggerServerEvent('vg-drugs:server:PotAction', id, 'fertilize')
        end

    elseif action == 'plant' then
        if (VG.Inventory.Count(Config.Weed.Items.seed) or 0) < 1 then
            return lib.notify({ type = 'error', description = _L('no_seed') or 'Tohumun yok.' })
        end

        if lib.progressCircle({
            duration = Config.Weed.Times.plantSeed,
            position = 'bottom',
            label = _L('planting_seed') or 'Tohum Ekiliyor...',
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'amb@world_human_gardener_plant@male@base', clip = 'base' }
        }) then
            TriggerServerEvent('vg-drugs:server:PotAction', id, 'plant')
        end

    elseif action == 'water' then
        if (VG.Inventory.Count(Config.Weed.Items.water) or 0) < 1 then
            return lib.notify({ type = 'error', description = _L('no_water') or 'Suyun yok.' })
        end

        if lib.progressCircle({
            duration = Config.Weed.Times.waterPlant,
            position = 'bottom',
            label = _L('watering') or 'Watering...',
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'amb@world_human_gardener_plant@male@base', clip = 'base' },
            prop = {
                model = `prop_ld_flow_bottle`,
                pos = vec3(0.12, 0.0, -0.01),
                rot = vec3(0.0, 120.0, 0.0),
                bone = 28422
            }
        }) then
            TriggerServerEvent('vg-drugs:server:PotAction', id, 'water')
        end

    elseif action == 'harvest' then
        if lib.progressCircle({
            duration = Config.Weed.Times.harvest,
            position = 'bottom',
            label = _L('harvesting') or 'Hasat Ediliyor...',
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'amb@world_human_gardener_plant@male@base', clip = 'base' }
        }) then
            TriggerServerEvent('vg-drugs:server:PotAction', id, 'harvest')
        end
    end
end)

RegisterNetEvent('vg-drugs:client:ProcessWeed', function(processType)
    local rawCount = VG.Inventory.Count(Config.Weed.Items.raw) or 0

    if processType == 'pack' then
        local reqPack = Config.Weed.Processing.PackRawRequired
        local bagCount = VG.Inventory.Count(Config.Weed.Items.bag) or 0
        local availableAmount = math.min(math.floor(rawCount / reqPack), bagCount)
        local maxAmount, minAmount = VG.Batch.ClampAvailable('weed_pack', availableAmount)
        if not maxAmount then
            return lib.notify({ type = 'error', description = _L('need_pack_requirements_count', reqPack) })
        end

        local input = lib.inputDialog(_L('production_amount_title'), {
            { type = 'number', label = _L('production_amount_label'), description = _L('production_amount_max', maxAmount), min = minAmount, max = maxAmount, default = minAmount }
        })
        if not input or not input[1] then return end
        local amount = VG.Batch.Sanitize('weed_pack', input[1], availableAmount)
        if not amount then return end

        if lib.progressCircle({
            duration = math.max(1500, math.min(Config.Weed.Times.processWeed * amount, 30000)),
            position = 'bottom',
            label = _L('packing_batch', amount),
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'misscarsteal4@actor', clip = 'actor_berating_loop' }
        }) then
            TriggerServerEvent('vg-drugs:server:ProcessWeed', 'pack', amount)
        end

    elseif processType == 'joint' then
        local reqJoint = Config.Weed.Processing.JointRawRequired
        local availableAmount = math.floor(rawCount / reqJoint)
        local maxAmount, minAmount = VG.Batch.ClampAvailable('weed_joint', availableAmount)
        if not maxAmount then
            return lib.notify({ type = 'error', description = _L('need_joint_requirements_count', reqJoint) })
        end

        local input = lib.inputDialog(_L('production_amount_title'), {
            { type = 'number', label = _L('production_amount_label'), description = _L('production_amount_max', maxAmount), min = minAmount, max = maxAmount, default = minAmount }
        })
        if not input or not input[1] then return end
        local amount = VG.Batch.Sanitize('weed_joint', input[1], availableAmount)
        if not amount then return end

        if lib.progressCircle({
            duration = math.max(1500, math.min(math.floor(Config.Weed.Times.processWeed / 2) * amount, 30000)),
            position = 'bottom',
            label = _L('rolling_batch', amount),
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'misscarsteal4@actor', clip = 'actor_berating_loop' }
        }) then
            TriggerServerEvent('vg-drugs:server:ProcessWeed', 'joint', amount)
        end
    end
end)

CreateThread(function()
    while true do
        Wait(0)

        local playerCoords = GetEntityCoords(cache.ped)

        for _, prop in pairs(SpawnedProps) do
            if prop.type == 'grow_light'
                and DoesEntityExist(prop.base)
                and prop.coords
                and prop.coords.x
                and #(playerCoords - vec3(prop.coords.x, prop.coords.y, prop.coords.z)) < 15.0 then

                DrawLightWithRange(
                    prop.coords.x,
                    prop.coords.y,
                    prop.coords.z + 0.5,
                    150, 0, 255,
                    4.0,
                    10.0
                )
            end
        end
    end
end)

RegisterNUICallback('closePanel', function(_, cb)
    SetNuiFocus(false, false)
    cb(1)
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerServerEvent('vg-drugs:server:RequestProps')
end)

RegisterNetEvent('esx:playerLoaded', function()
    TriggerServerEvent('vg-drugs:server:RequestProps')
end)

RegisterNetEvent('QBX:Client:OnPlayerLoaded', function()
    TriggerServerEvent('vg-drugs:server:RequestProps')
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    Wait(3500)
    clearAllSpawnedProps()
    TriggerServerEvent('vg-drugs:server:RequestProps')
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end

    if placingProp and currentProp and DoesEntityExist(currentProp) then
        DeleteEntity(currentProp)
    end

    lib.hideTextUI()
    SetNuiFocus(false, false)
    clearAllSpawnedProps()
end)
