local inDrugLab = false
local currentLabType = nil
local currentVehicleNetId = nil
local currentPlate = nil
local currentVehicleCoords = nil
local labZones = {}
local isMinigameActive = false
local stageResult = nil
local vendorPed = nil

local combatBlockNoticeAt = 0
local lastVehicleSyncAt = 0
local lastSentVehicleCoords = nil

local function maybeNotifyCombatBlocked()
    local now = GetGameTimer()
    if now - combatBlockNoticeAt < 3000 then return end
    combatBlockNoticeAt = now
    lib.notify({ type = 'inform', description = _L('interior_combat_blocked') })
end

local function clearLabZones()
    for _, zoneId in ipairs(labZones) do exports.ox_target:removeZone(zoneId) end
    labZones = {}
end

local function loadInteriorAt(coords)
    local interior = GetInteriorAtCoords(coords.x, coords.y, coords.z)
    if interior and interior ~= 0 then
        LoadInterior(interior)
        local timeout = GetGameTimer() + 5000
        while not IsInteriorReady(interior) and GetGameTimer() < timeout do Wait(50) end
    end
    RequestCollisionAtCoord(coords.x, coords.y, coords.z)
end

local function notify(desc, t) lib.notify({ type = t or 'inform', description = desc }) end

local function openStageGame(payload)
    isMinigameActive = true
    stageResult = nil
    SetNuiFocus(true, true)
    SendNUIMessage(payload)
    local timeoutAt = GetGameTimer() + ((payload.duration or 14) * 1000) + 5000
    while isMinigameActive do
        Wait(100)
        if GetGameTimer() > timeoutAt then
            isMinigameActive = false
            stageResult = { success = false, outcome = 'cancel', quality = 0 }
            SetNuiFocus(false, false)
            SendNUIMessage({ action = 'forceClose' })
            notify(_L('minigame_timeout'), 'error')
            break
        end
    end
    SetNuiFocus(false, false)
    return stageResult
end

local function playPourBottleScene()
    local ped = cache.ped
    local coords = Config.Meth.Interior.cookStation
    local dict = 'mp_ped_interaction'
    local bottleModel = `prop_cs_spray_can`
    lib.requestAnimDict(dict)
    lib.requestModel(bottleModel)
    local bottle = CreateObject(bottleModel, coords.x, coords.y, coords.z, true, true, false)
    AttachEntityToEntity(bottle, ped, GetPedBoneIndex(ped, 57005), 0.14, 0.02, -0.04, 80.0, 160.0, 10.0, true, true, false, true, 1, true)
    TaskTurnPedToFaceCoord(ped, coords.x, coords.y, coords.z, 700)
    Wait(700)
    TaskPlayAnim(ped, dict, 'handshake_guy_a', 2.0, 2.0, 2200, 49, 0.0, false, false, false)
    Wait(2200)
    ClearPedTasks(ped)
    if DoesEntityExist(bottle) then DeleteEntity(bottle) end
end

local function playAddChemicalsScene()
    local ped = cache.ped
    local coords = Config.Meth.Interior.cookStation
    local dict = 'anim@heists@box_carry@'
    local jarModel = `bkr_prop_meth_ammonia`
    lib.requestAnimDict(dict)
    lib.requestModel(jarModel)
    local jar = CreateObject(jarModel, coords.x, coords.y, coords.z, true, true, false)
    AttachEntityToEntity(jar, ped, GetPedBoneIndex(ped, 57005), 0.14, 0.02, -0.02, 10.0, 90.0, 0.0, true, true, false, true, 1, true)
    TaskTurnPedToFaceCoord(ped, coords.x, coords.y, coords.z, 500)
    Wait(500)
    TaskPlayAnim(ped, dict, 'idle', 2.0, 2.0, 2000, 49, 0.0, false, false, false)
    Wait(2000)
    ClearPedTasks(ped)
    if DoesEntityExist(jar) then DeleteEntity(jar) end
end

local function playStirScene(ms)
    local ped = cache.ped
    local coords = Config.Meth.Interior.cookStation
    local dict = 'anim@amb@business@coc@coc_unpack_cut_left@'
    local spoonModel = `bkr_prop_coke_spatula_04`
    lib.requestAnimDict(dict)
    lib.requestModel(spoonModel)
    local spoon = CreateObject(spoonModel, coords.x, coords.y, coords.z, true, true, false)
    AttachEntityToEntity(spoon, ped, GetPedBoneIndex(ped, 57005), 0.12, 0.02, -0.03, -20.0, 100.0, -20.0, true, true, false, true, 1, true)
    TaskTurnPedToFaceCoord(ped, coords.x, coords.y, coords.z, 500)
    Wait(500)
    TaskPlayAnim(ped, dict, 'coke_cut_v1_coccutter', 2.0, 2.0, ms or 4000, 49, 0.0, false, false, false)
    Wait(ms or 4000)
    ClearPedTasks(ped)
    if DoesEntityExist(spoon) then DeleteEntity(spoon) end
end

local function playTrayPourScene()
    local ped = cache.ped
    local coords = Config.Meth.Interior.breakStation
    local dict = 'anim@heists@ornate_bank@thermal_charge'
    local trayModel = `xm3_prop_xm3_sheet_acid_01a`
    lib.requestAnimDict(dict)
    lib.requestModel(trayModel)
    local tray = CreateObject(trayModel, coords.x, coords.y, coords.z, true, true, false)
    AttachEntityToEntity(tray, ped, GetPedBoneIndex(ped, 57005), 0.18, 0.03, -0.06, 15.0, 85.0, -10.0, true, true, false, true, 1, true)
    TaskTurnPedToFaceCoord(ped, coords.x, coords.y, coords.z, 500)
    Wait(500)
    TaskPlayAnim(ped, dict, 'thermal_charge', 2.0, 2.0, 2500, 49, 0.0, false, false, false)
    Wait(2500)
    ClearPedTasks(ped)
    if DoesEntityExist(tray) then DeleteEntity(tray) end
end

local function playBreakScene()
    local ped = cache.ped
    local coords = Config.Meth.Interior.breakStation
    local dict = 'anim@amb@business@coc@coc_unpack_cut_left@'
    local hammerModel = `prop_tool_hammer`
    lib.requestAnimDict(dict)
    lib.requestModel(hammerModel)
    local hammer = CreateObject(hammerModel, coords.x, coords.y, coords.z, true, true, false)
    AttachEntityToEntity(hammer, ped, GetPedBoneIndex(ped, 57005), 0.12, 0.03, -0.02, -80.0, 90.0, 0.0, true, true, false, true, 1, true)
    TaskTurnPedToFaceCoord(ped, coords.x, coords.y, coords.z, 500)
    Wait(500)
    TaskPlayAnim(ped, dict, 'coke_cut_v1_coccutter', 2.0, 2.0, 3000, 49, 0.0, false, false, false)
    Wait(3000)
    ClearPedTasks(ped)
    if DoesEntityExist(hammer) then DeleteEntity(hammer) end
end

local function playPackScene()
    local ped = cache.ped
    local coords = Config.Meth.Interior.breakStation
    local dict = 'anim@heists@ornate_bank@grab_cash'
    local bagModel = `bkr_prop_meth_smallbag_01a`
    lib.requestAnimDict(dict)
    lib.requestModel(bagModel)
    local bag = CreateObject(bagModel, coords.x, coords.y, coords.z, true, true, false)
    AttachEntityToEntity(bag, ped, GetPedBoneIndex(ped, 57005), 0.13, 0.02, -0.04, 0.0, 90.0, 0.0, true, true, false, true, 1, true)
    TaskTurnPedToFaceCoord(ped, coords.x, coords.y, coords.z, 500)
    Wait(500)
    TaskPlayAnim(ped, dict, 'intro', 2.0, 2.0, 2600, 49, 0.0, false, false, false)
    Wait(2600)
    ClearPedTasks(ped)
    if DoesEntityExist(bag) then DeleteEntity(bag) end
end

local function runCookingBatchStage(stageKey, amount)
    local stageMeta = {
        pour_liquid = { title = _L('meth_stage_pour_title'), desc = _L('meth_stage_pour_desc'), icon = '🧪', duration = 12, easy = true },
        add_chem = { title = _L('meth_stage_chem_title'), desc = _L('meth_stage_chem_desc'), icon = '⚗️', duration = 13, easy = false },
        pour_tray = { title = _L('meth_stage_tray_title'), desc = _L('meth_stage_tray_desc'), icon = '🥣', duration = 12, easy = false },
        break_tray = { title = _L('meth_stage_break_title'), desc = _L('meth_stage_break_desc'), icon = '🔨', duration = 13, easy = false },
        weigh_pack = { title = _L('meth_stage_pack_title'), desc = _L('meth_stage_pack_desc'), icon = '📦', duration = 14, easy = false },
    }
    local meta = stageMeta[stageKey]
    return openStageGame({ action = 'openBatchStage', locale = Config.Locale or 'tr', stage = stageKey, title = meta.title, desc = meta.desc, icon = meta.icon, duration = meta.duration, batchAmount = amount, easy = meta.easy })
end

local function runFullCookFlow(amount)
    playPourBottleScene()
    local r1 = runCookingBatchStage('pour_liquid', amount)
    if not r1 or not r1.success then return false, r1 end

    playAddChemicalsScene()
    local r2 = runCookingBatchStage('add_chem', amount)
    if not r2 or not r2.success then return false, r2 end

    playStirScene(4500)
    local avg = math.floor(((r1.quality or 0) + (r2.quality or 0)) / 2)
    return true, { quality = avg, stage = 'cook' }
end

local function runFullPackFlow(amount)
    playTrayPourScene()
    local r3 = runCookingBatchStage('pour_tray', amount)
    if not r3 or not r3.success then return false, r3 end

    playBreakScene()
    local r4 = runCookingBatchStage('break_tray', amount)
    if not r4 or not r4.success then return false, r4 end

    playPackScene()
    local r5 = runCookingBatchStage('weigh_pack', amount)
    if not r5 or not r5.success then return false, r5 end

    local avg = math.floor(((r3.quality or 0) + (r4.quality or 0) + (r5.quality or 0)) / 3)
    return true, { quality = avg, stage = 'pack' }
end

local function askBatchAmountDialog(label, maxAmount)
    local input = lib.inputDialog(label, {
        { type = 'number', label = 'Miktar', description = ('Maximum %s'):format(maxAmount), min = 1, max = maxAmount, default = maxAmount }
    })
    if not input or not input[1] then return nil end
    local amount = math.floor(tonumber(input[1]) or 0)
    if amount < 1 then return nil end
    if amount > maxAmount then amount = maxAmount end
    return amount
end

local function startMethCookSequence()
    if not inDrugLab then return end
    local cSacid = exports.ox_inventory:Search('count', Config.Meth.Items.sacid) or 0
    local cLithium = exports.ox_inventory:Search('count', Config.Meth.Items.lithium) or 0
    local cHcacid = exports.ox_inventory:Search('count', Config.Meth.Items.hcacid) or 0
    local cAmmonia = exports.ox_inventory:Search('count', Config.Meth.Items.ammonia) or 0
    local maxAmount = math.min(cSacid, cLithium, cHcacid, cAmmonia)

    if maxAmount < 1 then
        return notify('You are missing chemical materials. You need all 4 chemical types for production.', 'error')
    end

    local amount = askBatchAmountDialog('How many batches do you want to process?', maxAmount)
    if not amount then return end

    TriggerServerEvent('vg-drugs:server:SetCaravanSmoke', currentVehicleNetId, true)

    local ok, result = runFullCookFlow(amount)
    if not ok then
        TriggerServerEvent('vg-drugs:server:SetCaravanSmoke', currentVehicleNetId, false)
        if result and result.outcome == 'explode' then
            return TriggerServerEvent('vg-drugs:server:MethAction', 'fail_explosion', { plate = currentPlate, vehicleNetId = currentVehicleNetId, dispatchCoords = currentVehicleCoords })
        end
        return TriggerServerEvent('vg-drugs:server:MethAction', 'fail_poison', { plate = currentPlate, vehicleNetId = currentVehicleNetId, dispatchCoords = currentVehicleCoords })
    end

    if lib.progressCircle({ duration = math.max(3000, math.min(18000, amount * 350)), position = 'bottom', label = ('The mixture is crystallizing... (%sx)'):format(amount), canCancel = false, disable = { move = true, car = true, combat = true } }) then
        TriggerServerEvent('vg-drugs:server:SetCaravanSmoke', currentVehicleNetId, false)
        TriggerServerEvent('vg-drugs:server:MethAction', 'cook_batch', { amount = amount, quality = result.quality or 70, plate = currentPlate, vehicleNetId = currentVehicleNetId })
    else
        TriggerServerEvent('vg-drugs:server:SetCaravanSmoke', currentVehicleNetId, false)
    end
end

local function startMethBreakSequence()
    if not inDrugLab then return end
    local rawItem = Config.Meth.Items.raw
    local bagItem = Config.Meth.Items.bag
    local rawCount = exports.ox_inventory:Search('count', rawItem) or 0
    local bagCount = exports.ox_inventory:Search('count', bagItem) or 0

    if rawCount < 1 then return notify('There is no raw product to break down.', 'error') end

    local input = lib.inputDialog('Packaging Stage', {
        { type = 'number', label = 'Amount to Process', description = ('Maximum %s'):format(rawCount), min = 1, max = rawCount, default = rawCount },
        { type = 'select', label = 'Paket Boyutu', options = {
            { value = '10g', label = '10 Gram Packs (Street Sale)' },
            { value = '1kg', label = ('1 Kilogram Brick (%sx Raw)'):format(Config.Meth.Processing.RawToKilo) }
        }, default = '10g'}
    })

    if not input or not input[1] or not input[2] then return end
    local amount = math.floor(tonumber(input[1]) or 0)
    local packageSize = input[2]

    if packageSize == '10g' and bagCount < amount then
        return notify('You do not have enough empty bags.', 'error')
    end

    local ok, result = runFullPackFlow(amount)
    if not ok then
        if result and result.outcome == 'explode' then
            return TriggerServerEvent('vg-drugs:server:MethAction', 'fail_explosion', { plate = currentPlate, vehicleNetId = currentVehicleNetId, dispatchCoords = currentVehicleCoords })
        end
        return notify('Packaging stage failed.', 'error')
    end

    if lib.progressCircle({ duration = math.max(2500, math.min(16000, amount * 300)), position = 'bottom', label = ('Products are being weighed and packed...'), canCancel = false, disable = { move = true, car = true, combat = true } }) then
        TriggerServerEvent('vg-drugs:server:MethAction', 'pack_batch', { amount = amount, size = packageSize, quality = result.quality or 70, plate = currentPlate, vehicleNetId = currentVehicleNetId })
    end
end

local function createLabZones(labType)
    clearLabZones()
    if labType ~= 'meth' then return end
    labZones[#labZones + 1] = exports.ox_target:addSphereZone({ coords = Config.Meth.Interior.cookStation, radius = 1.2, options = {{ name = 'meth_lab_cook', icon = 'fas fa-flask', label = _L('target_meth_liquid'), onSelect = startMethCookSequence }} })
    labZones[#labZones + 1] = exports.ox_target:addSphereZone({ coords = Config.Meth.Interior.breakStation, radius = 1.2, options = {{ name = 'meth_lab_pack', icon = 'fas fa-box', label = _L('target_meth_pack'), onSelect = startMethBreakSequence }} })
    labZones[#labZones + 1] = exports.ox_target:addSphereZone({ coords = Config.Meth.Interior.stashStation, radius = 1.2, options = {{ name = 'meth_lab_stash', icon = 'fas fa-box-open', label = _L('target_open_stash'), onSelect = function() TriggerServerEvent('vg-drugs:server:OpenActiveLabStash') end }} })
    labZones[#labZones + 1] = exports.ox_target:addSphereZone({ coords = Config.Meth.Interior.exit, radius = 1.2, options = {{ name = 'meth_lab_exit', icon = 'fas fa-door-open', label = _L('target_exit_caravan'), onSelect = function() TriggerServerEvent('vg-drugs:server:ExitActiveDrugLab') end }} })
end

RegisterNUICallback('batchStageResult', function(data, cb)
    stageResult = data or { success = false, outcome = 'cancel', quality = 0 }
    isMinigameActive = false
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterCommand('nuikapat', function()
    if isMinigameActive then
        SendNUIMessage({ action = 'forceClose' })
        SetNuiFocus(false, false)
        stageResult = { success = false, outcome = 'cancel', quality = 0 }
        isMinigameActive = false
        ClearPedTasks(cache.ped)
        notify(_L('nui_forced_closed'), 'error')
    else
        notify('There is no active minigame.', 'error')
    end
end)

RegisterNetEvent('vg-drugs:client:EnterDrugLab', function(payload)
    if not payload or not payload.vehicleNetId or not payload.coords then return end
    currentPlate = payload.plate
    currentVehicleCoords = payload.coords
    currentLabType = payload.labType
    currentVehicleNetId = payload.vehicleNetId
    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Wait(0) end
    local spawn = Config.Meth.Interior.spawn
    loadInteriorAt(spawn)
    SetEntityCoords(cache.ped, spawn.x, spawn.y, spawn.z, false, false, false, false)
    SetEntityHeading(cache.ped, spawn.w)
    Wait(250)
    inDrugLab = true
    createLabZones(payload.labType)
    TriggerServerEvent('vg-drugs:server:SyncLabVehiclePosition')
    DoScreenFadeIn(500)
    notify('Acid interior meth lab opened.', 'success')
end)

RegisterNetEvent('vg-drugs:client:ExitDrugLab', function(returnCoords, heading)
    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Wait(0) end
    clearLabZones()
    lastVehicleSyncAt = 0
    lastSentVehicleCoords = nil
    UnlockMinimapPosition()
    SetNuiFocus(false, false)
    ClearPedTasks(cache.ped)
    SetEntityCoords(cache.ped, returnCoords.x, returnCoords.y, returnCoords.z)
    SetEntityHeading(cache.ped, heading or 0.0)
    inDrugLab = false
    currentLabType = nil
    currentVehicleNetId = nil
    currentPlate = nil
    currentVehicleCoords = nil
    Wait(250)
    DoScreenFadeIn(500)
end)

RegisterNetEvent('vg-drugs:client:ForceExitLab', function(returnCoords, heading)
    if not inDrugLab then return end
    DoScreenFadeOut(350)
    while not IsScreenFadedOut() do Wait(0) end
    clearLabZones()
    lastVehicleSyncAt = 0
    lastSentVehicleCoords = nil
    UnlockMinimapPosition()
    SetNuiFocus(false, false)
    ClearPedTasks(cache.ped)
    SetEntityCoords(cache.ped, returnCoords.x, returnCoords.y, returnCoords.z)
    SetEntityHeading(cache.ped, heading or 0.0)
    inDrugLab = false
    currentLabType = nil
    currentVehicleNetId = nil
    currentPlate = nil
    currentVehicleCoords = nil
    Wait(250)
    DoScreenFadeIn(350)
end)

RegisterNetEvent('vg-drugs:client:OpenLabStash', function(stashId, label)
    if not exports.ox_inventory:openInventory('stash', stashId) then notify((label or 'Stash') .. ' could not be opened.', 'error') end
end)

RegisterNetEvent('vg-drugs:client:LabVehiclePosition', function(payload)
    if not inDrugLab or not payload or not payload.coords then return end
    if payload.vehicleNetId then currentVehicleNetId = payload.vehicleNetId end
    currentVehicleCoords = payload.coords
end)

RegisterNetEvent('vg-drugs:client:ExplodeVehicleAtCoords', function(coords)
    if not coords then return end
    AddExplosion(coords.x + 0.0, coords.y + 0.0, coords.z + 0.0, 2, 20.0, true, false, 1.0)
end)

RegisterNetEvent('vg-drugs:client:PoisonGas', function()
    local ped = cache.ped
    notify('Chemical gas has spread!', 'warning')
    ShakeGameplayCam('DRUNK_SHAKE', 1.1)
    SetPedToRagdoll(ped, 3000, 3000, 0, false, false, false)
    ApplyDamageToPed(ped, 10, false)
    SetTimeout(9000, function() StopGameplayCamShaking(true) end)
end)

RegisterNetEvent('vg-drugs:client:UseMethTable', function() notify('In this version, meth_table is used as a setup item. Use the NPC to set up the caravan.') end)

exports.ox_target:addModel(Config.Meth.Props.camper, {
    {
        name = 'enter_drug_lab',
        icon = 'fas fa-truck-medical',
        label = _L('target_enter_lab'),
        canInteract = function(entity) return Entity(entity).state.drugLabType ~= nil end,
        onSelect = function(data)
            local netId = (data and data.entity and DoesEntityExist(data.entity)) and NetworkGetNetworkIdFromEntity(data.entity) or 0
            TriggerServerEvent('vg-drugs:server:EnterActiveDrugLab', netId)
        end
    }
})

CreateThread(function()
    local npcData = Config.CaravanLabs.vendor
    lib.requestModel(npcData.ped)
    vendorPed = CreatePed(4, npcData.ped, npcData.coords.x, npcData.coords.y, npcData.coords.z - 1.0, npcData.coords.w, false, true)
    SetEntityAsMissionEntity(vendorPed, true, true)
    SetBlockingOfNonTemporaryEvents(vendorPed, true)
    FreezeEntityPosition(vendorPed, true)
    SetEntityInvincible(vendorPed, true)

    exports.ox_target:addLocalEntity(vendorPed, {
        {
            name = 'vg_lab_vendor_setup',
            icon = 'fas fa-flask',
            label = npcData.label or _L('target_setup_lab'),
            onSelect = function()
                local coords = GetEntityCoords(cache.ped)
                local vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 12.0, 0, 71)
                if not vehicle or vehicle == 0 then return notify('There is no suitable caravan nearby.', 'error') end
                if GetEntityModel(vehicle) ~= joaat(Config.Meth.Props.camper) then return notify('Setup can only be applied to a Journey caravan.', 'error') end
                lib.registerContext({
                    id = 'vg_lab_vendor_menu',
                    title = 'Caravan Laboratory',
                    options = {
                        {
                            title = 'Meth Lab Kur (Acid Interior)',
                            description = 'Links the acid interior to the caravan.',
                            icon = 'flask',
                            onSelect = function()
                                local plate = GetVehicleNumberPlateText(vehicle)
                                local netId = NetworkGetNetworkIdFromEntity(vehicle)
                                TriggerServerEvent('vg-drugs:server:SetupCaravanLabFromNpc', plate, netId, 'meth')
                            end
                        }
                    }
                })
                lib.showContext('vg_lab_vendor_menu')
            end
        }
    })
end)

CreateThread(function()
    while true do
        if inDrugLab then
            DisablePlayerFiring(cache.ped, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 44, true)
            DisableControlAction(0, 45, true)
            DisableControlAction(0, 140, true)
            DisableControlAction(0, 141, true)
            DisableControlAction(0, 142, true)
            DisableControlAction(0, 143, true)
            DisableControlAction(0, 257, true)
            DisableControlAction(0, 263, true)
            DisableControlAction(0, 264, true)
            if IsDisabledControlJustPressed(0, 24) or IsDisabledControlJustPressed(0, 140) or IsDisabledControlJustPressed(0, 141) or IsDisabledControlJustPressed(0, 142) then maybeNotifyCombatBlocked() end

            local now = GetGameTimer()
            if now - lastVehicleSyncAt >= 4000 then
                lastVehicleSyncAt = now
                local serverSyncSent = false
                if currentVehicleNetId and NetworkDoesEntityExistWithNetworkId(currentVehicleNetId) then
                    local vehicle = NetworkGetEntityFromNetworkId(currentVehicleNetId)
                    if vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
                        local coords = GetEntityCoords(vehicle)
                        currentVehicleCoords = { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 }
                        if (not lastSentVehicleCoords) or #(coords - lastSentVehicleCoords) > 2.0 then
                            TriggerServerEvent('vg-drugs:server:SyncLabVehiclePosition')
                            lastSentVehicleCoords = coords
                            serverSyncSent = true
                        end
                    end
                end
                if not serverSyncSent then TriggerServerEvent('vg-drugs:server:SyncLabVehiclePosition') end
            end

            if currentVehicleCoords then
                DisplayRadar(true)
                SetPlayerBlipPositionThisFrame(currentVehicleCoords.x + 0.0, currentVehicleCoords.y + 0.0)
                LockMinimapPosition(currentVehicleCoords.x + 0.0, currentVehicleCoords.y + 0.0)
                SetRadarAsExteriorThisFrame()
            end

            Wait(0)
        else
            UnlockMinimapPosition()
            Wait(1000)
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if vendorPed and DoesEntityExist(vendorPed) then DeleteEntity(vendorPed) end
    clearLabZones()
    lastVehicleSyncAt = 0
    lastSentVehicleCoords = nil
    UnlockMinimapPosition()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'forceClose' })
end)

local activeSmokeEffects = {}

RegisterNetEvent('vg-drugs:client:ToggleCaravanSmoke', function(vehicleNetId, state)
    if not NetworkDoesEntityExistWithNetworkId(vehicleNetId) then return end
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)

    if state then
        if not activeSmokeEffects[vehicleNetId] then
            lib.requestNamedPtfxAsset('core')
            UseParticleFxAssetNextCall('core')
            local fx = StartParticleFxLoopedOnEntity('exp_grd_bzgas_smoke', vehicle, 0.0, 0.0, 1.5, 0.0, 0.0, 0.0, 1.0, false, false, false)
            activeSmokeEffects[vehicleNetId] = fx
        end
    else
        if activeSmokeEffects[vehicleNetId] then
            StopParticleFxLooped(activeSmokeEffects[vehicleNetId], 0)
            activeSmokeEffects[vehicleNetId] = nil
        end
    end
end)
