local recentlySoldPeds = {}

exports.ox_target:addGlobalPed({
    {
        name = 'sell_drugs_to_npc',
        icon = 'fas fa-hand-holding-dollar',
        label = _L('target_offer_goods'),
        canInteract = function(entity, distance, coords, name, bone)
            if IsPedDeadOrDying(entity, true) or IsPedAPlayer(entity) or not IsPedHuman(entity) then return false end

            local hasDrugs = false
            for itemName, _ in pairs(Config.NPC.SellableDrugs) do
                local count = exports.ox_inventory:Search('count', itemName)
                if count and count > 0 then
                    hasDrugs = true
                    break
                end
            end

            return hasDrugs
        end,
        onSelect = function(data)
            local entity = data.entity
            local menuOptions = {}

            TaskTurnPedToFaceEntity(entity, cache.ped, 2000)

            for itemName, itemData in pairs(Config.NPC.SellableDrugs) do
                local count = exports.ox_inventory:Search('count', itemName)
                if count and count > 0 then
                    table.insert(menuOptions, {
                        title = itemData.label,
                        description = ('You have %s on you. Show it to the buyer.'):format(count),
                        icon = itemData.icon,
                        onSelect = function()
                            local wantedAmount = math.random(1, 10)
                            if wantedAmount > count then wantedAmount = count end

                            if math.random(1, 100) <= Config.NPC.DispatchChance then
                                exports['ps-dispatch']:CustomAlert({
                                    coords = GetEntityCoords(cache.ped),
                                    message = 'Suspicious Drug Sale',
                                    dispatchCode = '10-31',
                                    description = 'A street drug sale was reported.',
                                    radius = 0,
                                    sprite = 51,
                                    color = 1,
                                    scale = 1.0,
                                    length = 3,
                                })
                            end

                            if lib.progressCircle({
                                duration = Config.NPC.SellTime or 4000,
                                position = 'bottom',
                                label = 'Negotiating with customer...',
                                useWhileDead = false,
                                canCancel = true,
                                disable = { car = true, move = true, combat = true },
                                anim = { dict = 'misscarsteal4@actor', clip = 'actor_berating_loop' }
                            }) then
                                TriggerServerEvent('vg-drugs:server:SellToNPC', NetworkGetNetworkIdFromEntity(entity), itemName, wantedAmount)
                            else
                                lib.notify({ type = 'error', description = 'Sale cancelled.' })
                            end
                        end
                    })
                end
            end

            lib.registerContext({
                id = 'npc_drug_sell_menu',
                title = 'Negotiate With Customer',
                options = menuOptions
            })

            lib.showContext('npc_drug_sell_menu')
        end
    }
})
