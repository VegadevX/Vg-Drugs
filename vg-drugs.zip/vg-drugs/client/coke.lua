local placingProp = false
local currentProp = nil
local harvestedBushes = {}

local function StartCokeTablePlacement()
    if placingProp then return end
    placingProp = true

    local model = Config.Coke.Props.table
    lib.requestModel(model)

    local playerPed = cache.ped
    local coords = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)

    currentProp = CreateObject(GetHashKey(model), coords.x, coords.y, coords.z, false, false, false)
    SetEntityAlpha(currentProp, 150, false)
    SetEntityCollision(currentProp, false, false)

    lib.showTextUI('[E] Place Table  \n[SCROLL] Rotate  \n[BACKSPACE] Cancel', { position = 'right-center', icon = 'hand' })

    CreateThread(function()
        while placingProp do
            Wait(0)
            local pCoords = GetEntityCoords(cache.ped)
            local forward = GetEntityForwardVector(cache.ped)
            local targetCoords = pCoords + (forward * 1.5)

            local _, groundZ = GetGroundZFor_3dCoord(targetCoords.x, targetCoords.y, targetCoords.z + 1.0, 0)
            SetEntityCoordsNoOffset(currentProp, targetCoords.x, targetCoords.y, groundZ, false, false, false)

            if IsControlPressed(0, 14) then heading = heading + 2.0
            elseif IsControlPressed(0, 15) then heading = heading - 2.0 end

            if IsControlJustPressed(0, 38) then
                placingProp = false
                lib.hideTextUI()
                DeleteEntity(currentProp)

                TriggerServerEvent('vg-drugs:server:SaveProp', model, 'coke_table', { x = targetCoords.x, y = targetCoords.y, z = groundZ }, heading, Config.Coke.Items.table)
                break
            end

            if IsControlJustPressed(0, 177) then
                placingProp = false
                lib.hideTextUI()
                DeleteEntity(currentProp)
                break
            end
        end
    end)
end

RegisterNetEvent('vg-drugs:client:UseCokeTable', function()
    StartCokeTablePlacement()
end)

RegisterCommand('testcoke', function()
    local ped = cache.ped
    local coords = GetEntityCoords(ped)
    local forward = GetEntityForwardVector(ped)
    local spawnCoords = coords + (forward * 1.5)

    local _, groundZ = GetGroundZFor_3dCoord(spawnCoords.x, spawnCoords.y, spawnCoords.z + 2.0, 0)

    local model = Config.Coke.Props.bush
    lib.requestModel(model)

    local bush = CreateObject(model, spawnCoords.x, spawnCoords.y, groundZ, false, false, false)
    PlaceObjectOnGroundProperly(bush)
    FreezeEntityPosition(bush, true)
    SetEntityAsMissionEntity(bush, true, true)

    lib.notify({ type = 'success', description = 'Test coca bush spawned in front of you. Use scissors to test harvesting.' })
end, false)

VG.Target.AddModel(Config.Coke.Props.bush, {
    {
        name = 'harvest_coke_bush',
        icon = 'fas fa-leaf',
        label = _L('target_harvest_coke'),
        canInteract = function(entity)
            return not harvestedBushes[entity]
        end,
        onSelect = function(data)
            local entity = data.entity

            local hasScissors = VG.Inventory.Count(Config.Coke.Items.scissors)
            if hasScissors < 1 then
                lib.notify({ type = 'error', description = 'You need scissors in your inventory to cut the leaves.' })
                return
            end

            if lib.progressCircle({
                duration = Config.Coke.Times.harvestLeaf,
                position = 'bottom',
                useWhileDead = false,
                canCancel = true,
                disable = { car = true, move = true, combat = true },
                anim = { dict = 'amb@world_human_gardener_plant@male@base', clip = 'base' },
            }) then
                harvestedBushes[entity] = true
                SetEntityAlpha(entity, 150, false)

                TriggerServerEvent('vg-drugs:server:HarvestCoke')
            else
                lib.notify({ type = 'error', description = 'Harvest action was cancelled.' })
            end
        end
    }
})

VG.Target.AddModel(Config.Coke.Props.table, {
    {
        name = 'coke_process',
        icon = 'fas fa-mortar-pestle',
        label = _L('target_process_leaves'),
        onSelect = function()
            TriggerEvent('vg-drugs:client:CokeAction', 'process')
        end
    },
    {
        name = 'coke_pack',
        icon = 'fas fa-box',
        label = _L('target_pack_coke'),
        onSelect = function()
            TriggerEvent('vg-drugs:client:CokeAction', 'pack')
        end
    },
    {
        name = 'coke_pickup',
        icon = 'fas fa-hand',
        label = _L('target_pickup_table'),
        onSelect = function(data)
            local coords = GetEntityCoords(data.entity)
            TriggerServerEvent('vg-drugs:server:PickupCokeTable', coords)
        end
    }
})

RegisterNetEvent('vg-drugs:client:CokeAction', function(action)
    if action == 'process' then
        local reqLeaf = Config.Coke.Processing.LeafToRaw
        local leafCount = VG.Inventory.Count(Config.Coke.Items.leaf) or 0
        local availableAmount = math.floor(leafCount / reqLeaf)
        local maxAmount, minAmount = VG.Batch.ClampAvailable('coke_process', availableAmount)
        if not maxAmount then
            return lib.notify({ type = 'error', description = _L('not_enough_materials_count', reqLeaf) })
        end

        local input = lib.inputDialog(_L('production_amount_title'), {
            { type = 'number', label = _L('production_amount_label'), description = _L('production_amount_max', maxAmount), min = minAmount, max = maxAmount, default = minAmount }
        })
        if not input or not input[1] then return end
        local amount = VG.Batch.Sanitize('coke_process', input[1], availableAmount)
        if not amount then return end

        if lib.progressCircle({
            duration = math.max(1500, math.min(Config.Coke.Times.processCoke or 15000, 5000 * amount)),
            position = 'bottom',
            label = _L('processing_batch', amount),
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'mini@repair', clip = 'fixing_a_ped' }
        }) then
            TriggerServerEvent('vg-drugs:server:CokeAction', 'process', amount)
        end

    elseif action == 'pack' then
        local reqRaw = Config.Coke.Processing.RawToPack
        local rawCount = VG.Inventory.Count(Config.Coke.Items.raw) or 0
        local bagCount = VG.Inventory.Count(Config.Coke.Items.bag) or 0
        local availableAmount = math.min(math.floor(rawCount / reqRaw), bagCount)
        local maxAmount, minAmount = VG.Batch.ClampAvailable('coke_pack', availableAmount)
        if not maxAmount then
            return lib.notify({ type = 'error', description = _L('missing_pack_materials') })
        end

        local input = lib.inputDialog(_L('production_amount_title'), {
            { type = 'number', label = _L('production_amount_label'), description = _L('production_amount_max', maxAmount), min = minAmount, max = maxAmount, default = minAmount }
        })
        if not input or not input[1] then return end
        local amount = VG.Batch.Sanitize('coke_pack', input[1], availableAmount)
        if not amount then return end

        if lib.progressCircle({
            duration = math.max(1500, math.min(Config.Coke.Times.processCoke or 15000, 3000 * amount)),
            position = 'bottom',
            label = _L('packing_batch', amount),
            canCancel = true,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'anim@amb@business@weed@weed_inspecting_high_dry@', clip = 'weed_inspecting_high_base_inspector' }
        }) then
            TriggerServerEvent('vg-drugs:server:CokeAction', 'pack', amount)
        end
    end
end)

local spawnedBushes = {}

local function SpawnCokeField()
    local model = Config.Coke.Props.bush
    lib.requestModel(model)

    for i = 1, Config.Coke.Field.amount do
        local x = Config.Coke.Field.center.x + math.random(-Config.Coke.Field.radius, Config.Coke.Field.radius)
        local y = Config.Coke.Field.center.y + math.random(-Config.Coke.Field.radius, Config.Coke.Field.radius)

        local z = Config.Coke.Field.center.z + 50.0
        local foundGround, groundZ = GetGroundZFor_3dCoord(x, y, z, 0)
        if not foundGround then groundZ = Config.Coke.Field.center.z end

        local bush = CreateObject(model, x, y, groundZ, false, false, false)
        PlaceObjectOnGroundProperly(bush)
        FreezeEntityPosition(bush, true)
        SetEntityAsMissionEntity(bush, true, true)

        table.insert(spawnedBushes, bush)
    end
end

CreateThread(function()
    SpawnCokeField()
end)

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        for _, bush in ipairs(spawnedBushes) do
            DeleteEntity(bush)
        end
    end
end)

