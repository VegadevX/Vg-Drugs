VG = VG or {}

local function resourceStarted(name)
    return name and GetResourceState(name) == 'started'
end

VG.Notify = function(type_, description)
    if lib and lib.notify then
        return lib.notify({ type = type_ or 'inform', description = description })
    end
    print(('[vg-drugs] %s: %s'):format(type_ or 'info', description or ''))
end


VG.Batch = VG.Batch or {}

function VG.Batch.GetLimits(key)
    local limits = Config.BatchProduction and Config.BatchProduction[key] or {}
    local minAmount = math.max(1, math.floor(tonumber(limits.min) or 1))
    local maxAmount = math.max(minAmount, math.floor(tonumber(limits.max) or 1))
    return minAmount, maxAmount
end

function VG.Batch.ClampAvailable(key, available)
    local minLimit, maxLimit = VG.Batch.GetLimits(key)
    available = math.floor(tonumber(available) or 0)
    local maxAvailable = math.min(available, maxLimit)
    if maxAvailable < minLimit then return nil, minLimit, maxAvailable end
    return maxAvailable, minLimit, maxLimit
end

function VG.Batch.Sanitize(key, amount, available)
    local maxAvailable, minLimit = VG.Batch.ClampAvailable(key, available)
    if not maxAvailable then return nil end
    amount = math.floor(tonumber(amount) or minLimit)
    if amount < minLimit then amount = minLimit end
    if amount > maxAvailable then amount = maxAvailable end
    return amount, minLimit, maxAvailable
end

VG.Inventory = {}
function VG.Inventory.Count(item)
    if not item then return 0 end
    local inv = ((Config.Inventory or 'auto'):lower()):gsub('_', '-')

    -- ox_inventory has a reliable client-side count export. For every other inventory,
    -- use the server bridge so item counting stays compatible with qb/ps/lj/qs/custom inventories.
    if (inv == 'auto' or inv == 'ox' or inv == 'ox-inventory') and resourceStarted('ox_inventory') then
        local ok, count = pcall(function() return exports.ox_inventory:Search('count', item) end)
        if ok then return tonumber(count) or 0 end
    end

    local count = lib.callback.await('vg-drugs:server:GetItemCount', false, item)
    return tonumber(count) or 0
end

VG.Target = {}
local targetZones = {}

local function convertOptionsForQb(options)
    local converted = {}
    for _, opt in ipairs(options or {}) do
        converted[#converted + 1] = {
            num = #converted + 1,
            type = 'client',
            icon = opt.icon,
            label = opt.label,
            canInteract = opt.canInteract,
            action = function(entity)
                if opt.onSelect then opt.onSelect({ entity = entity }) end
            end
        }
    end
    return converted
end

function VG.Target.AddModel(models, options)
    local target = (Config.Target or 'auto'):lower()
    if (target == 'auto' or target == 'ox' or target == 'ox_target') and resourceStarted('ox_target') then
        return exports.ox_target:addModel(models, options)
    end
    if (target == 'auto' or target == 'qb' or target == 'qb-target') and resourceStarted('qb-target') then
        return exports['qb-target']:AddTargetModel(models, { options = convertOptionsForQb(options), distance = Config.TargetDistance or 2.0 })
    end
    if (target == 'auto' or target == 'qtarget') and resourceStarted('qtarget') then
        return exports.qtarget:AddTargetModel(models, { options = convertOptionsForQb(options), distance = Config.TargetDistance or 2.0 })
    end
    if target == 'custom' and Config.CustomTarget and Config.CustomTarget.AddModel then return Config.CustomTarget.AddModel(models, options) end
end

function VG.Target.AddLocalEntity(entity, options)
    local target = (Config.Target or 'auto'):lower()
    if (target == 'auto' or target == 'ox' or target == 'ox_target') and resourceStarted('ox_target') then
        return exports.ox_target:addLocalEntity(entity, options)
    end
    if (target == 'auto' or target == 'qb' or target == 'qb-target') and resourceStarted('qb-target') then
        return exports['qb-target']:AddTargetEntity(entity, { options = convertOptionsForQb(options), distance = Config.TargetDistance or 2.0 })
    end
    if (target == 'auto' or target == 'qtarget') and resourceStarted('qtarget') then
        return exports.qtarget:AddTargetEntity(entity, { options = convertOptionsForQb(options), distance = Config.TargetDistance or 2.0 })
    end
    if target == 'custom' and Config.CustomTarget and Config.CustomTarget.AddLocalEntity then return Config.CustomTarget.AddLocalEntity(entity, options) end
end

function VG.Target.RemoveLocalEntity(entity)
    if resourceStarted('ox_target') then pcall(function() exports.ox_target:removeLocalEntity(entity) end) end
    if resourceStarted('qb-target') then pcall(function() exports['qb-target']:RemoveTargetEntity(entity) end) end
    if resourceStarted('qtarget') then pcall(function() exports.qtarget:RemoveTargetEntity(entity) end) end
    if (Config.Target or ''):lower() == 'custom' and Config.CustomTarget and Config.CustomTarget.RemoveLocalEntity then Config.CustomTarget.RemoveLocalEntity(entity) end
end

function VG.Target.AddGlobalPed(options)
    local target = (Config.Target or 'auto'):lower()
    if (target == 'auto' or target == 'ox' or target == 'ox_target') and resourceStarted('ox_target') then
        return exports.ox_target:addGlobalPed(options)
    end
    if (target == 'auto' or target == 'qb' or target == 'qb-target') and resourceStarted('qb-target') then
        return exports['qb-target']:AddGlobalPed({ options = convertOptionsForQb(options), distance = Config.TargetDistance or 2.0 })
    end
    if target == 'custom' and Config.CustomTarget and Config.CustomTarget.AddGlobalPed then return Config.CustomTarget.AddGlobalPed(options) end
end

function VG.Target.AddSphereZone(data)
    local target = (Config.Target or 'auto'):lower()
    if (target == 'auto' or target == 'ox' or target == 'ox_target') and resourceStarted('ox_target') then
        return exports.ox_target:addSphereZone(data)
    end
    if (target == 'auto' or target == 'qb' or target == 'qb-target') and resourceStarted('qb-target') then
        local name = data.name or ('vg_drugs_zone_' .. math.random(100000, 999999))
        exports['qb-target']:AddCircleZone(name, data.coords, data.radius or 1.2, { name = name, useZ = true }, { options = convertOptionsForQb(data.options), distance = data.distance or 2.0 })
        targetZones[name] = true
        return name
    end
    if (target == 'auto' or target == 'qtarget') and resourceStarted('qtarget') then
        local name = data.name or ('vg_drugs_zone_' .. math.random(100000, 999999))
        exports.qtarget:AddCircleZone(name, data.coords, data.radius or 1.2, { name = name, useZ = true }, { options = convertOptionsForQb(data.options), distance = data.distance or 2.0 })
        targetZones[name] = true
        return name
    end
    if target == 'custom' and Config.CustomTarget and Config.CustomTarget.AddSphereZone then return Config.CustomTarget.AddSphereZone(data) end
end

function VG.Target.RemoveZone(zoneId)
    if not zoneId then return end
    if resourceStarted('ox_target') then pcall(function() exports.ox_target:removeZone(zoneId) end) end
    if resourceStarted('qb-target') then pcall(function() exports['qb-target']:RemoveZone(zoneId) end) end
    if resourceStarted('qtarget') then pcall(function() exports.qtarget:RemoveZone(zoneId) end) end
    if (Config.Target or ''):lower() == 'custom' and Config.CustomTarget and Config.CustomTarget.RemoveZone then Config.CustomTarget.RemoveZone(zoneId) end
end
