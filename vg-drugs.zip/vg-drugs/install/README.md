# VG Drugs Installation Guide

## Requirements
- `ox_lib`
- `ox_target`
- `oxmysql`
- One supported inventory setup:
  - `ox_inventory`
  - `qb-inventory`
  - `esx_inventory` or another ESX-compatible inventory bridge you use on your server

## 1) Copy the resource
Place the `vg-drugs` folder inside your server resources directory.

## 2) Import the database
Run the SQL inside `db.sql`.

## 3) Add the resource to your server config
```cfg
ensure ox_lib
ensure ox_target
ensure oxmysql
ensure vg-drugs
```

## 4) Configure the script
Open `config.lua`.

Important options:
- `Config.Framework = 'auto'`
- `Config.Locale = 'en'` (`en`, `tr`, `es`, `fr`)
- `Config.Target = 'ox_target'`
- `Config.Inventory = 'ox_inventory'`

The script now starts in English by default.

## 5) Inventory item images
All image file names inside `install/` already match the item names.
Use the same names in your inventory item definitions.

## 6) Inventory item examples

### ox_inventory (`data/items.lua`)
```lua
['weed_seed'] = { label = 'Weed Seed', weight = 50, stack = true, close = true, description = 'Used to plant weed.' },
['empty_pot'] = { label = 'Empty Pot', weight = 250, stack = true, close = true },
['fertilizer'] = { label = 'Fertilizer', weight = 100, stack = true, close = true },
['grow_light'] = { label = 'Grow Light', weight = 1000, stack = true, close = true },
['weed_raw'] = { label = 'Raw Weed', weight = 100, stack = true, close = true },
['weed_pack'] = { label = 'Weed Pack', weight = 100, stack = true, close = true },
['weed_joint'] = { label = 'Joint', weight = 50, stack = true, close = true },
['weed_table'] = { label = 'Weed Table', weight = 3000, stack = false, close = true },
['coke_leaf'] = { label = 'Coca Leaf', weight = 100, stack = true, close = true },
['coke_pile'] = { label = 'Cocaine Pile', weight = 100, stack = true, close = true },
['coke_pack'] = { label = 'Cocaine Pack', weight = 100, stack = true, close = true },
['coke_shear'] = { label = 'Scissors', weight = 100, stack = false, close = true },
['coke_table'] = { label = 'Cocaine Table', weight = 3000, stack = false, close = true },
['coke_chemical'] = { label = 'Chemical', weight = 100, stack = true, close = true },
['meth_sacid'] = { label = 'Sulfuric Acid', weight = 100, stack = true, close = true },
['meth_lithium'] = { label = 'Lithium', weight = 100, stack = true, close = true },
['meth_hcacid'] = { label = 'Hydrochloric Acid', weight = 100, stack = true, close = true },
['meth_ammonia'] = { label = 'Ammonia', weight = 100, stack = true, close = true },
['meth_table'] = { label = 'Meth Table', weight = 3000, stack = false, close = true },
['meth_tray'] = { label = 'Meth Tray', weight = 100, stack = true, close = true },
['meth_tray2'] = { label = 'Raw Meth', weight = 100, stack = true, close = true },
['meth_pack'] = { label = 'Meth Pack', weight = 100, stack = true, close = true },
['empty_bag'] = { label = 'Empty Bag', weight = 10, stack = true, close = true },
```

### qb-inventory / QBCore shared items
```lua
['weed_seed'] = { name = 'weed_seed', label = 'Weed Seed', weight = 50, type = 'item', image = 'weed_seed.png', unique = false, useable = false, shouldClose = true, description = 'Used to plant weed.' },
['empty_pot'] = { name = 'empty_pot', label = 'Empty Pot', weight = 250, type = 'item', image = 'empty_pot.png', unique = false, useable = false, shouldClose = true, description = 'An empty planting pot.' },
['fertilizer'] = { name = 'fertilizer', label = 'Fertilizer', weight = 100, type = 'item', image = 'fertilizer.png', unique = false, useable = false, shouldClose = true, description = 'Plant fertilizer.' },
['grow_light'] = { name = 'grow_light', label = 'Grow Light', weight = 1000, type = 'item', image = 'grow_light.png', unique = false, useable = false, shouldClose = true, description = 'A portable grow light.' },
['weed_raw'] = { name = 'weed_raw', label = 'Raw Weed', weight = 100, type = 'item', image = 'weed_raw.png', unique = false, useable = false, shouldClose = true, description = 'Freshly harvested weed.' },
['weed_pack'] = { name = 'weed_pack', label = 'Weed Pack', weight = 100, type = 'item', image = 'weed_pack.png', unique = false, useable = false, shouldClose = true, description = 'Packed weed ready for sale.' },
['weed_joint'] = { name = 'weed_joint', label = 'Joint', weight = 50, type = 'item', image = 'weed_joint.png', unique = false, useable = false, shouldClose = true, description = 'A rolled joint.' },
['weed_table'] = { name = 'weed_table', label = 'Weed Table', weight = 3000, type = 'item', image = 'weed_table.png', unique = false, useable = false, shouldClose = true, description = 'Processing table for weed.' },
['coke_leaf'] = { name = 'coke_leaf', label = 'Coca Leaf', weight = 100, type = 'item', image = 'coke_leaf.png', unique = false, useable = false, shouldClose = true, description = 'Fresh coca leaves.' },
['coke_pile'] = { name = 'coke_pile', label = 'Cocaine Pile', weight = 100, type = 'item', image = 'coke_pile.png', unique = false, useable = false, shouldClose = true, description = 'Processed cocaine powder.' },
['coke_pack'] = { name = 'coke_pack', label = 'Cocaine Pack', weight = 100, type = 'item', image = 'coke_pack.png', unique = false, useable = false, shouldClose = true, description = 'Bagged cocaine pack.' },
['coke_shear'] = { name = 'coke_shear', label = 'Scissors', weight = 100, type = 'item', image = 'coke_shear.png', unique = false, useable = false, shouldClose = true, description = 'Used to harvest coca leaves.' },
['coke_table'] = { name = 'coke_table', label = 'Cocaine Table', weight = 3000, type = 'item', image = 'coke_table.png', unique = false, useable = false, shouldClose = true, description = 'Processing table for cocaine.' },
['meth_sacid'] = { name = 'meth_sacid', label = 'Sulfuric Acid', weight = 100, type = 'item', image = 'meth_sacid.png', unique = false, useable = false, shouldClose = true, description = 'Meth ingredient.' },
['meth_lithium'] = { name = 'meth_lithium', label = 'Lithium', weight = 100, type = 'item', image = 'meth_lithium.png', unique = false, useable = false, shouldClose = true, description = 'Meth ingredient.' },
['meth_hcacid'] = { name = 'meth_hcacid', label = 'Hydrochloric Acid', weight = 100, type = 'item', image = 'meth_hcacid.png', unique = false, useable = false, shouldClose = true, description = 'Meth ingredient.' },
['meth_ammonia'] = { name = 'meth_ammonia', label = 'Ammonia', weight = 100, type = 'item', image = 'meth_ammonia.png', unique = false, useable = false, shouldClose = true, description = 'Meth ingredient.' },
['meth_table'] = { name = 'meth_table', label = 'Meth Table', weight = 3000, type = 'item', image = 'meth_table.png', unique = false, useable = false, shouldClose = true, description = 'Processing table for meth.' },
['meth_tray2'] = { name = 'meth_tray2', label = 'Raw Meth', weight = 100, type = 'item', image = 'meth_tray2.png', unique = false, useable = false, shouldClose = true, description = 'Raw meth product.' },
['meth_pack'] = { name = 'meth_pack', label = 'Meth Pack', weight = 100, type = 'item', image = 'meth_pack.png', unique = false, useable = false, shouldClose = true, description = 'Packed meth ready for sale.' },
['empty_bag'] = { name = 'empty_bag', label = 'Empty Bag', weight = 10, type = 'item', image = 'empty_bag.png', unique = false, useable = false, shouldClose = true, description = 'Small empty bag.' },
```

### ESX item SQL example
```sql
INSERT INTO items (name, label, weight) VALUES
('weed_seed', 'Weed Seed', 1),
('empty_pot', 'Empty Pot', 1),
('fertilizer', 'Fertilizer', 1),
('grow_light', 'Grow Light', 1),
('weed_raw', 'Raw Weed', 1),
('weed_pack', 'Weed Pack', 1),
('weed_joint', 'Joint', 1),
('weed_table', 'Weed Table', 1),
('coke_leaf', 'Coca Leaf', 1),
('coke_pile', 'Cocaine Pile', 1),
('coke_pack', 'Cocaine Pack', 1),
('coke_shear', 'Scissors', 1),
('coke_table', 'Cocaine Table', 1),
('coke_chemical', 'Chemical', 1),
('meth_sacid', 'Sulfuric Acid', 1),
('meth_lithium', 'Lithium', 1),
('meth_hcacid', 'Hydrochloric Acid', 1),
('meth_ammonia', 'Ammonia', 1),
('meth_table', 'Meth Table', 1),
('meth_tray', 'Meth Tray', 1),
('meth_tray2', 'Raw Meth', 1),
('meth_pack', 'Meth Pack', 1),
('empty_bag', 'Empty Bag', 1);
```

## 7) Image names
Move the PNG files from `install/` into your inventory image folder. Do not rename them.

## 8) Notes
- The script is configured for `ox_target` by default.
- Default language is English.
- If you switch `Config.Locale`, NUI, target labels, and locale-driven notifications will change to that language.
