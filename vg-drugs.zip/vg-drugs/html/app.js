const app = document.getElementById('app');
const plantPanel = document.getElementById('plantPanel');
const stageTitle = document.getElementById('stageTitle');
const stageDesc = document.getElementById('stageDesc');
const stageIcon = document.getElementById('stageIcon');
const timeLeft = document.getElementById('timeLeft');
const batchAmount = document.getElementById('batchAmount');
const qualityEl = document.getElementById('quality');
const statusText = document.getElementById('statusText');
const stageIds = ['pour_liquid', 'add_chem', 'pour_tray', 'break_tray', 'weigh_pack'];

let currentLocale = 'en';
let plantCountdown = null;

let state = {
  active: false,
  stage: null,
  duration: 12,
  endAt: 0,
  quality: 100,
  easy: true,
  tick: null,
  moveDir: 1,
  pos: 50,
  pourProgress: 0,
  recipe: [],
  recipeIndex: 0,
  trayValue: 50,
  trayFlow: false,
  breakHits: 0,
  packHits: 0,
  weight: 10.0,
  previewIndex: 0,
  previewUntil: 0
};

function tr(key) {
  const pack = (window.VG_LANG && window.VG_LANG[currentLocale]) || window.VG_LANG.en;
  return pack[key] || window.VG_LANG.en[key] || key;
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function qs(id) {
  return document.getElementById(id);
}

function showStage(id) {
  for (const stageId of stageIds) {
    qs(`stage-${stageId}`).classList.add('hidden');
  }
  qs(`stage-${id}`).classList.remove('hidden');
}

function applyVerticalChemLayout() {
  const btn1 = qs('chem1Btn');
  const btn2 = qs('chem2Btn');
  const btn3 = qs('chem3Btn');

  const buttons = [btn1, btn2, btn3].filter(Boolean);
  if (!buttons.length) return;

  const parent = btn1.parentElement;
  if (parent) {
    parent.style.display = 'flex';
    parent.style.flexDirection = 'column';
    parent.style.alignItems = 'stretch';
    parent.style.gap = '12px';
    parent.style.width = '100%';
  }

  buttons.forEach((btn) => {
    btn.style.display = 'block';
    btn.style.width = '100%';
    btn.style.maxWidth = '100%';
    btn.style.margin = '0';
  });
}

function formatTime(totalSeconds) {
  if (totalSeconds <= 0) return `0 ${tr('seconds')}`;
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  
  let str = [];
  if (h > 0) {
    // 1 saat veya üzeriyse saat, dakika ve saniye göster
    str.push(`${h}h`);
    str.push(`${m}m`);
    str.push(`${s}${tr('seconds')}`);
  } else {
    // 1 saatin altındaysa sadece dakika ve saniye göster
    if (m > 0) str.push(`${m}m`);
    str.push(`${s}${tr('seconds')}`);
  }
  
  return str.join(" ");
}
function applyLocale(locale) {
  currentLocale = (window.VG_LANG && window.VG_LANG[locale]) ? locale : 'en';
  document.documentElement.lang = currentLocale;

  qs('labLabel').textContent = tr('lab');
  qs('timeLabel').textContent = tr('time');
  qs('amountLabel').textContent = tr('amount');
  qs('qualityLabel').textContent = tr('quality');
  qs('escText').textContent = tr('esc_cancel');

  qs('pourHint').textContent = tr('pour_hint');
  qs('chemHint').textContent = tr('chem_hint');
  qs('trayHint').textContent = tr('tray_hint');
  qs('breakHint').textContent = tr('break_hint');
  qs('packHint').textContent = tr('pack_hint');

  qs('chem1Btn').textContent = tr('chem_1');
  qs('chem2Btn').textContent = tr('chem_2');
  qs('chem3Btn').textContent = tr('chem_3');

  qs('recipeTitle').textContent = tr('recipe_title');

  qs('plantTitle').textContent = tr('plant_status_title');
  qs('plantHint').textContent = tr('plant_status_hint');
  qs('fertilizedLabel').textContent = tr('fertilized');
  qs('plantedLabel').textContent = tr('planted');
  qs('stageLabel').textContent = tr('stage');
  qs('waterLabel').textContent = tr('water');
  qs('lightLabel').textContent = tr('light');
  qs('remainingLabel').textContent = tr('remaining');
  qs('confirmPlantBtn').textContent = tr('confirm');

  applyVerticalChemLayout();
}

function updateTop() {
  qualityEl.textContent = Math.round(state.quality);
  timeLeft.textContent = Math.max(0, Math.ceil((state.endAt - Date.now()) / 1000));
}

function reduceQuality(amount, reason) {
  state.quality = clamp(state.quality - amount, 0, 100);
  statusText.textContent = reason;
}

function stopPlantCountdown() {
  if (plantCountdown) {
    clearInterval(plantCountdown);
    plantCountdown = null;
  }
}

function hideAll() {
  stopPlantCountdown();
  app.classList.add('hidden');
  plantPanel.classList.add('hidden');
  document.body.style.display = 'none';
}

function finish(outcome) {
  if (!state.active) return;

  state.active = false;

  if (state.tick) {
    clearInterval(state.tick);
    state.tick = null;
  }

  const success = outcome === 'success';

  fetch(`https://${GetParentResourceName()}/batchStageResult`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json; charset=UTF-8'
    },
    body: JSON.stringify({
      success,
      outcome,
      quality: Math.round(state.quality)
    })
  }).catch(() => {});

  setTimeout(() => {
    hideAll();
  }, 10);
}

function renderRecipe(showPreview = false) {
  const names = {
    1: tr('chem_1').replace('1 - ', ''),
    2: tr('chem_2').replace('2 - ', ''),
    3: tr('chem_3').replace('3 - ', '')
  };

  const root = qs('recipeOrder');
  root.innerHTML = '';

  state.recipe.forEach((val, idx) => {
    const div = document.createElement('div');
    div.className = `pill ${idx < state.recipeIndex ? 'done' : ''}`;
    div.textContent = (showPreview || idx < state.recipeIndex) ? names[val] : '?';
    root.appendChild(div);
  });
}

function startPreviewSequence() {
  state.previewIndex = 0;
  state.previewUntil = Date.now() + 2400;

  renderRecipe(false);
  qs('memorizeBox').textContent = tr('memorise');

  const interval = setInterval(() => {
    if (!state.active || state.stage !== 'add_chem') {
      clearInterval(interval);
      return;
    }

    renderRecipe(true);

    if (Date.now() > state.previewUntil) {
      clearInterval(interval);
      qs('memorizeBox').textContent = '';
      renderRecipe(false);
    }
  }, 280);
}

function startGame(data) {
  applyLocale(data.locale || 'en');

  state = {
    active: true,
    stage: data.stage,
    duration: data.duration || 12,
    endAt: Date.now() + ((data.duration || 12) * 1000),
    quality: 100,
    easy: !!data.easy,
    tick: null,
    moveDir: 1,
    pos: 50,
    pourProgress: 0,
    recipe: [],
    recipeIndex: 0,
    trayValue: 50,
    trayFlow: false,
    breakHits: 0,
    packHits: 0,
    weight: 10.0,
    previewIndex: 0,
    previewUntil: 0
  };

  stageTitle.textContent = data.title || 'Stage';
  stageDesc.textContent = data.desc || '';
  stageIcon.textContent = data.icon || '🧪';
  batchAmount.textContent = `${data.batchAmount || 1}x`;
  statusText.textContent = tr('status_started');

  document.body.style.display = 'block';
  app.classList.remove('hidden');
  plantPanel.classList.add('hidden');

  showStage(state.stage);
  applyVerticalChemLayout();

  qs('breakHits').textContent = '0 / 4';
  qs('packHits').textContent = '0 / 3';

  if (state.stage === 'add_chem') {
    const pool = [1, 2, 3];
    state.recipe = [];

    for (let i = 0; i < 4; i++) {
      state.recipe.push(pool[Math.floor(Math.random() * pool.length)]);
    }

    renderRecipe(false);
    startPreviewSequence();
  }

  updateTop();
  state.tick = setInterval(tickGame, 70);
}

function tickGame() {
  if (!state.active) return;

  const remain = state.endAt - Date.now();
  updateTop();

  if (remain <= 0) {
    if (state.stage === 'pour_liquid' && state.pourProgress >= 100) return finish('success');
    if (state.stage === 'add_chem' && state.recipeIndex >= state.recipe.length) return finish('success');
    if (state.stage === 'pour_tray' && state.quality >= 55) return finish('success');
    if (state.stage === 'break_tray' && state.breakHits >= 4) return finish('success');
    if (state.stage === 'weigh_pack' && state.packHits >= 3) return finish('success');

    return finish(state.quality < 35 ? 'explode' : 'poison');
  }

  if (state.stage === 'pour_liquid') {
    const speed = state.easy ? 1.8 : 2.5;
    state.pos += state.moveDir * speed;

    if (state.pos >= 95) state.moveDir = -1;
    if (state.pos <= 5) state.moveDir = 1;

    qs('pourNeedle').style.left = `${state.pos}%`;
    qs('pourProgress').firstElementChild.style.width = `${state.pourProgress}%`;
  }

  if (state.stage === 'pour_tray') {
    if (state.trayFlow) {
      state.trayValue += state.easy ? 0.68 : 0.92;
    } else {
      state.trayValue -= 0.26;
    }

    state.trayValue = clamp(state.trayValue, 0, 100);
    qs('trayValue').textContent = `${Math.round(state.trayValue)}%`;
    qs('trayNeedle').style.transform = `scaleX(${state.trayValue / 100})`;

    if (state.trayValue < 41 || state.trayValue > 59) {
      reduceQuality(0.35, tr('status_pack_bad'));
    }
  }

  if (state.stage === 'break_tray') {
    const speed = state.easy ? 2.2 : 2.9;
    state.pos += state.moveDir * speed;

    if (state.pos >= 95) state.moveDir = -1;
    if (state.pos <= 5) state.moveDir = 1;

    qs('breakNeedle').style.left = `${state.pos}%`;
  }

  if (state.stage === 'weigh_pack') {
    qs('weightValue').textContent = state.weight.toFixed(1);
    const normalized = clamp((state.weight / 20) * 100, 0, 100);
    qs('weightNeedle').style.transform = `scaleX(${normalized / 100})`;
  }
}

function within(pos, min, max) {
  return pos >= min && pos <= max;
}

function handleChemInput(selected) {
  if (!state.active || state.stage !== 'add_chem') return;
  if (Date.now() < state.previewUntil) return;

  const needed = state.recipe[state.recipeIndex];

  if (selected === needed) {
    state.recipeIndex += 1;
    renderRecipe(true);
    statusText.textContent = tr('status_chem_ok');

    if (state.recipeIndex >= state.recipe.length) {
      finish('success');
    }
  } else {
    reduceQuality(10, tr('status_chem_bad'));

    if (state.quality <= 0) {
      finish('poison');
    }
  }
}

function onSpace() {
  if (!state.active) return;

  if (state.stage === 'pour_liquid') {
    if (within(state.pos, 45, 59)) {
      state.pourProgress = clamp(state.pourProgress + 25, 0, 100);
      statusText.textContent = tr('status_good_pour');

      if (state.pourProgress >= 100) {
        finish('success');
      }
    } else {
      reduceQuality(10, tr('status_spill'));

      if (state.quality <= 0) {
        finish('explode');
      }
    }
  }

  if (state.stage === 'pour_tray') {
    state.trayFlow = !state.trayFlow;
    statusText.textContent = state.trayFlow ? tr('status_flow_open') : tr('status_flow_closed');

    if (within(state.trayValue, 43, 57) && !state.trayFlow) {
      finish(state.quality >= 35 ? 'success' : 'poison');
    }
  }

  if (state.stage === 'break_tray') {
    if (within(state.pos, 47, 55)) {
      state.breakHits += 1;
      qs('breakHits').textContent = `${state.breakHits} / 4`;
      statusText.textContent = tr('status_hit');

      if (state.breakHits >= 4) {
        finish('success');
      }
    } else {
      reduceQuality(9, tr('status_bad_hit'));

      if (state.quality <= 0) {
        finish('explode');
      }
    }
  }

  if (state.stage === 'weigh_pack') {
    if (state.weight >= 9.7 && state.weight <= 10.3) {
      state.packHits += 1;
      qs('packHits').textContent = `${state.packHits} / 3`;
      statusText.textContent = tr('status_pack_ok');
      state.weight = 10.0 + ((Math.random() * 1.6) - 0.8);

      if (state.packHits >= 3) {
        finish('success');
      }
    } else {
      reduceQuality(7, tr('status_pack_bad'));

      if (state.quality <= 0) {
        finish('poison');
      }
    }
  }
}

function closePlantPanel() {
  stopPlantCountdown();

  fetch(`https://${GetParentResourceName()}/closePanel`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json; charset=UTF-8'
    },
    body: '{}'
  }).catch(() => {});

  hideAll();
}

qs('confirmPlantBtn').addEventListener('click', closePlantPanel);
qs('closePlantBtn').addEventListener('click', closePlantPanel);

if (qs('chem1Btn')) {
  qs('chem1Btn').addEventListener('click', () => handleChemInput(1));
}

if (qs('chem2Btn')) {
  qs('chem2Btn').addEventListener('click', () => handleChemInput(2));
}

if (qs('chem3Btn')) {
  qs('chem3Btn').addEventListener('click', () => handleChemInput(3));
}

window.addEventListener('message', (event) => {
  const data = event.data || {};

  if (data.locale) {
    applyLocale(data.locale);
  }

  if (data.action === 'openBatchStage') {
    startGame(data);
  } else if (data.action === 'openPlantStatus') {
    applyLocale(data.locale || 'en');

    document.body.style.display = 'block';
    app.classList.add('hidden');
    plantPanel.classList.remove('hidden');

    stopPlantCountdown();

    qs('plantFertilized').textContent = data.values?.fertilized || '-';
    qs('plantPlanted').textContent = data.values?.planted || '-';
    qs('plantStage').textContent = data.values?.stage || '0/3';
    qs('plantLight').textContent = data.values?.light || '-';

    let rem = Number(data.values?.remaining || 0);
    let waterRem = Number(data.values?.water_seconds || 0);
    let waterPercent = data.values?.water || '0%'; // Yüzdeyi alıyoruz

    // İlk açıldığında yazıları ekrana bas
    qs('plantRemaining').textContent = formatTime(rem);
    qs('plantWater').textContent = waterRem > 0 ? `${waterPercent} (${formatTime(waterRem)})` : `${waterPercent} (Su Gerekiyor)`;

    // Canlı geri sayım döngüsü
    plantCountdown = setInterval(() => {
      rem = Math.max(0, rem - 1);
      waterRem = Math.max(0, waterRem - 1);

      qs('plantRemaining').textContent = formatTime(rem);
      qs('plantWater').textContent = waterRem > 0 ? `${waterPercent} (${formatTime(waterRem)})` : `${waterPercent} (Su Gerekiyor)`;

      if (rem <= 0 && waterRem <= 0) {
        stopPlantCountdown();
      }
    }, 1000);

  } else if (data.action === 'forceClose' || data.action === 'close') {
    stopPlantCountdown();

    state.active = false;

    if (state.tick) {
      clearInterval(state.tick);
      state.tick = null;
    }

    hideAll();
  }
});

window.addEventListener('keydown', (e) => {
  const key = e.key.toLowerCase();

  if (plantPanel && !plantPanel.classList.contains('hidden') && key === 'escape') {
    return closePlantPanel();
  }

  if (!state.active) return;

  if (key === 'escape') {
    return finish('cancel');
  }

  if (key === ' ') {
    e.preventDefault();
    return onSpace();
  }

  if (state.stage === 'add_chem' && ['1', '2', '3'].includes(key)) {
    return handleChemInput(Number(key));
  }

  if (state.stage === 'weigh_pack') {
    if (key === 'a') {
      state.weight = clamp(state.weight - 0.2, 0, 20);
    } else if (key === 'd') {
      state.weight = clamp(state.weight + 0.2, 0, 20);
    }
  }
});

applyVerticalChemLayout();