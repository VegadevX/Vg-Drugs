const app = document.getElementById('app');
const tempValue = document.getElementById('tempValue');
const pressureValue = document.getElementById('pressureValue');
const mixValue = document.getElementById('mixValue');
const tempFill = document.getElementById('tempFill');
const pressureFill = document.getElementById('pressureFill');
const mixFill = document.getElementById('mixFill');
const statusText = document.getElementById('statusText');
const stabilityValue = document.getElementById('stabilityValue');
const timeLeft = document.getElementById('timeLeft');
const phaseText = document.getElementById('phaseText');

let active = false;
let tickHandle = null;
let endAt = 0;

let state = {
  temp: 50,
  pressure: 50,
  mix: 50,
  stability: 100,
  duration: 45,
  mode: 'cook'
};

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function inSafeRange(value, min, max) {
  return value >= min && value <= max;
}

function updateUI() {
  tempValue.textContent = Math.round(state.temp);
  pressureValue.textContent = Math.round(state.pressure);
  mixValue.textContent = Math.round(state.mix);

  tempFill.style.width = `${state.temp}%`;
  pressureFill.style.width = `${state.pressure}%`;
  mixFill.style.width = `${state.mix}%`;

  stabilityValue.textContent = Math.round(state.stability);
  timeLeft.textContent = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
}

function penalty() {
  let bad = 0;

  if (!inSafeRange(state.temp, 42, 60)) bad += Math.abs(state.temp - 51) * 0.055;
  if (!inSafeRange(state.pressure, 45, 59)) bad += Math.abs(state.pressure - 52) * 0.075;
  if (!inSafeRange(state.mix, 40, 60)) bad += Math.abs(state.mix - 50) * 0.04;

  state.stability = clamp(state.stability - bad, 0, 100);
}

function applyDrift() {
  const hardMode = state.mode === 'pack';

  state.temp += (Math.random() * (hardMode ? 2.8 : 2.1)) - (hardMode ? 1.4 : 1.05);
  state.pressure += (Math.random() * (hardMode ? 3.2 : 2.4)) - (hardMode ? 1.6 : 1.2);
  state.mix += (Math.random() * 1.8) - 1.2;

  if (Math.random() < 0.11) state.temp += (Math.random() * 6) - 3;
  if (Math.random() < 0.10) state.pressure += (Math.random() * 7) - 3.5;
  if (Math.random() < 0.08) state.mix -= Math.random() * 3.5;

  state.temp = clamp(state.temp, 0, 100);
  state.pressure = clamp(state.pressure, 0, 100);
  state.mix = clamp(state.mix, 0, 100);
}

function catastrophicFailure() {
  return (
    state.temp >= 92 ||
    state.pressure >= 94 ||
    state.temp <= 8 ||
    state.pressure <= 6
  );
}

function finish(reason) {
  if (!active) return;
  active = false;

  if (tickHandle) {
    clearInterval(tickHandle);
    tickHandle = null;
  }

  let outcome = 'success';

  if (reason === 'explode') {
    outcome = 'explode';
  } else if (reason === 'cancel') {
    outcome = 'cancel';
  } else {
    if (state.stability < 30) outcome = 'explode';
    else if (state.stability < 60) outcome = 'poison';
    else outcome = 'success';
  }

  fetch(`https://${GetParentResourceName()}/methMinigameAdvancedResult`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify({
      success: outcome === 'success',
      outcome,
      stability: Math.round(state.stability),
      temp: Math.round(state.temp),
      pressure: Math.round(state.pressure),
      mix: Math.round(state.mix)
    })
  });

  app.classList.add('hidden');
}

function startMinigame(data) {
  state = {
    temp: data?.temp ?? 50,
    pressure: data?.pressure ?? 50,
    mix: data?.mix ?? 50,
    stability: 100,
    duration: data?.duration ?? 45,
    mode: data?.mode ?? 'cook'
  };

  phaseText.textContent = state.mode === 'pack'
    ? 'Balance the package without damaging the product'
    : 'Stabilize the mixture';

  statusText.textContent = 'Reactor active. Keep all values in the safe range.';
  app.classList.remove('hidden');
  active = true;
  endAt = Date.now() + (state.duration * 1000);

  updateUI();

  tickHandle = setInterval(() => {
    applyDrift();
    penalty();
    updateUI();

    if (catastrophicFailure()) {
      statusText.textContent = 'CRITICAL ERROR! The reactor is out of control.';
      finish('explode');
      return;
    }

    if (Date.now() >= endAt) {
      finish('done');
    }
  }, 120);
}

window.addEventListener('message', (event) => {
  const data = event.data;

  if (data.action === 'openAdvancedMethMinigame') {
    startMinigame(data);
  }

  if (data.action === 'closeMethMinigame') {
    finish('cancel');
  }
});

window.addEventListener('keydown', (e) => {
  if (!active) return;

  const key = e.key.toLowerCase();

  if (key === 'q') {
    state.temp = clamp(state.temp - 5, 0, 100);
    statusText.textContent = 'Temperature reduced.';
  } else if (key === 'e') {
    state.temp = clamp(state.temp + 5, 0, 100);
    statusText.textContent = 'Temperature increased.';
  } else if (key === 'a') {
    state.pressure = clamp(state.pressure - 6, 0, 100);
    statusText.textContent = 'Pressure released.';
  } else if (key === 'd') {
    state.pressure = clamp(state.pressure + 6, 0, 100);
    statusText.textContent = 'Pressure increased.';
  } else if (key === ' ') {
    e.preventDefault();
    state.mix = clamp(state.mix + 10, 0, 100);
    state.temp = clamp(state.temp + 1.5, 0, 100);
    statusText.textContent = 'Mixture stirred.';
  } else if (key === 'escape') {
    finish('cancel');
    return;
  }

  updateUI();
});
