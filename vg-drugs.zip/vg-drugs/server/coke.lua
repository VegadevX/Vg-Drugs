-- Framework and usable-item handling is provided by server/bridge/framework.lua.
local function registerUsable(itemName, cb)
    return VG.Framework.RegisterUsable(itemName, cb)
end

registerUsable(Config.Coke.Items.table, function(source, item)
    TriggerClientEvent('vg-drugs:client:UseCokeTable', source)
end)

RegisterNetEvent('vg-drugs:server:HarvestCoke', function()
    local src = source

    local scissorsCount = VG.Inventory.GetItemCount(src, Config.Coke.Items.scissors, nil, true) or 0

    if scissorsCount >= 1 then
        local yieldAmount = math.random(Config.Coke.Yield.min, Config.Coke.Yield.max)

        if math.random(1, 100) <= Config.Coke.Chances.extraLeaf then
            yieldAmount = yieldAmount + 2
        end

        VG.Inventory.AddItem(src, Config.Coke.Items.leaf, yieldAmount)
        TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = yieldAmount .. 'x coca leaf harvested.' })
    else
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You cannot do this without scissors!' })
    end
end)

RegisterNetEvent('vg-drugs:server:CokeAction', function(action, amount)
    local src = source
    if action == 'process' then
        amount = VG.Batch.Validate(src, 'coke_process', amount)
        if not amount then return end
        local reqLeaf = Config.Coke.Processing.LeafToRaw * amount
        local leafCount = VG.Inventory.GetItemCount(src, Config.Coke.Items.leaf) or 0

        if leafCount < reqLeaf then
            return TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = _L('not_enough_materials_count', reqLeaf) })
        end

        VG.Inventory.RemoveItem(src, Config.Coke.Items.leaf, reqLeaf)
        VG.Inventory.AddItem(src, Config.Coke.Items.raw, amount)
        TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = _L('processed_batch_success', amount) })

    elseif action == 'pack' then
        amount = VG.Batch.Validate(src, 'coke_pack', amount)
        if not amount then return end
        local reqRaw = Config.Coke.Processing.RawToPack * amount
        local rawCount = VG.Inventory.GetItemCount(src, Config.Coke.Items.raw) or 0
        local bagCount = VG.Inventory.GetItemCount(src, Config.Coke.Items.bag) or 0

        if rawCount < reqRaw or bagCount < amount then
            return TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = _L('missing_pack_materials') })
        end

        VG.Inventory.RemoveItem(src, Config.Coke.Items.raw, reqRaw)
        VG.Inventory.RemoveItem(src, Config.Coke.Items.bag, amount)

        if math.random(1, 100) <= Config.Coke.Chances.chemicalBurn then
            local PlayerPed = GetPlayerPed(src)
            SetEntityHealth(PlayerPed, GetEntityHealth(PlayerPed) - 40)
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = _L('process_failed_materials_lost') })
        else
            VG.Inventory.AddItem(src, Config.Coke.Items.packed, amount)
            TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = _L('packed_batch_success', amount) })
        end
    end
end)

RegisterNetEvent('vg-drugs:server:PickupCokeTable', function(coords)
    local src = source
    exports.oxmysql:execute('SELECT id, coords FROM vg_drug_props WHERE type = ?', {'coke_table'}, function(result)
        if result and result[1] then
            for _, row in ipairs(result) do
                local dbCoords = json.decode(row.coords)
                local dist = #(vec3(dbCoords.x, dbCoords.y, dbCoords.z) - coords)

                if dist < 2.0 then
                    exports.oxmysql:execute('DELETE FROM vg_drug_props WHERE id = ?', {row.id})
                    VG.Inventory.AddItem(src, Config.Coke.Items.table, 1)
                    TriggerClientEvent('vg-drugs:client:RemoveProp', -1, row.id)
                    TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'You picked up the table.' })
                    break
                end
            end
        end
    end)
end)
