local FrameworkName = Config.Framework or 'auto'
local QBCore, ESX = nil, nil
if FrameworkName == 'auto' or FrameworkName == 'qb' or FrameworkName == 'qbx' then pcall(function() QBCore = exports['qb-core']:GetCoreObject() end) end
if FrameworkName == 'auto' or FrameworkName == 'esx' then pcall(function() ESX = exports['es_extended']:getSharedObject() end) end
local function registerUsable(itemName, cb)
    if QBCore then return QBCore.Functions.CreateUseableItem(itemName, function(source, item) cb(source, item) end) end
    if ESX and ESX.RegisterUsableItem then return ESX.RegisterUsableItem(itemName, function(source, item, slot) cb(source, item, slot) end) end
end

registerUsable(Config.Coke.Items.table, function(source, item)
    TriggerClientEvent('vg-drugs:client:UseCokeTable', source)
end)

RegisterNetEvent('vg-drugs:server:HarvestCoke', function()
    local src = source

    local scissorsCount = exports.ox_inventory:GetItem(src, Config.Coke.Items.scissors, nil, true) or 0

    if scissorsCount >= 1 then
        local yieldAmount = math.random(Config.Coke.Yield.min, Config.Coke.Yield.max)

        if math.random(1, 100) <= Config.Coke.Chances.extraLeaf then
            yieldAmount = yieldAmount + 2
        end

        exports.ox_inventory:AddItem(src, Config.Coke.Items.leaf, yieldAmount)
        TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = yieldAmount .. 'x coca leaf harvested.' })
    else
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You cannot do this without scissors!' })
    end
end)

RegisterNetEvent('vg-drugs:server:CokeAction', function(action)
    local src = source

    if action == 'process' then
        local leafCount = exports.ox_inventory:GetItem(src, Config.Coke.Items.leaf, nil, true) or 0

        if leafCount < 1 then
            return TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Not enough coca leaves.' })
        end

        exports.ox_inventory:RemoveItem(src, Config.Coke.Items.leaf, 1)
        exports.ox_inventory:AddItem(src, Config.Coke.Items.raw, 1)
        TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'You successfully processed the leaves into cocaine powder.' })

    elseif action == 'pack' then
        local rawCount = exports.ox_inventory:GetItem(src, Config.Coke.Items.raw, nil, true) or 0
        local bagCount = exports.ox_inventory:GetItem(src, Config.Coke.Items.bag, nil, true) or 0

        if rawCount < 1 or bagCount < 1 then
            return TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You are missing materials (cocaine powder or empty bag).' })
        end

        exports.ox_inventory:RemoveItem(src, Config.Coke.Items.raw, 1)
        exports.ox_inventory:RemoveItem(src, Config.Coke.Items.bag, 1)

        if math.random(1, 100) <= Config.Coke.Chances.chemicalBurn then
            local PlayerPed = GetPlayerPed(src)
            SetEntityHealth(PlayerPed, GetEntityHealth(PlayerPed) - 40)
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'The chemical reaction went out of control! The acid burned your hand and the materials were destroyed.' })
        else
            exports.ox_inventory:AddItem(src, Config.Coke.Items.packed, 1)
            TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'You prepared 1x cocaine pack.' })
        end
    end
end)

RegisterNetEvent('vg-drugs:server:PickupCokeTable', function(coords)
    local src = source
    exports.oxmysql:execute('SELECT id, coords FROM vg_drug_props WHERE type = ?', {'coke_table'}, function(result)
        if result and result[1] then
            for _, row in ipairs(result) do
                local dbCoords = json.decode(row.coords)
                local dist = #(vec3(dbCoords.x, dbCoords.y, dbCoords.z) - coords)

                if dist < 2.0 then
                    exports.oxmysql:execute('DELETE FROM vg_drug_props WHERE id = ?', {row.id})
                    exports.ox_inventory:AddItem(src, Config.Coke.Items.table, 1)
                    TriggerClientEvent('vg-drugs:client:RemoveProp', -1, row.id)
                    TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = 'You picked up the table.' })
                    break
                end
            end
        end
    end)
end)
