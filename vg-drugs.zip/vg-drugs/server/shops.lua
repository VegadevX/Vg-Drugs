RegisterNetEvent('vg-drugs:server:BuyDrugItem', function(shopKey, itemKey, amount)
    local src = source
    local shop = Config.DrugShops[shopKey]

    if not shop then return end

    local itemData = shop.items[itemKey]

    if not itemData then return end

    amount = tonumber(amount)
    if not amount or amount < 1 then return end

    local totalPrice = itemData.price * amount

    local money = VG.Inventory.GetItemCount(src, Config.NPC.MoneyItem or 'cash') or 0

    if money >= totalPrice then
        VG.Inventory.RemoveItem(src, Config.NPC.MoneyItem or 'cash', totalPrice)
        VG.Inventory.AddItem(src, itemData.item, amount)
        TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = amount .. 'x ' .. itemData.label .. '  purchased. -$' .. totalPrice })
    else
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You do not have enough cash. Required: $' .. totalPrice })
    end
end)
