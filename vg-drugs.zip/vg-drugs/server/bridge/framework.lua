VG = VG or {}

local function resourceStarted(name)
    return name and GetResourceState(name) == 'started'
end

VG.Framework = { name = 'standalone', object = nil }
CreateThread(function()
    local fw = (Config.Framework or 'auto'):lower()
    if (fw == 'auto' or fw == 'qb' or fw == 'qbx') and resourceStarted('qb-core') then
        pcall(function() VG.Framework.object = exports['qb-core']:GetCoreObject(); VG.Framework.name = resourceStarted('qbx_core') and 'qbx' or 'qb' end)
    end
    if (fw == 'auto' or fw == 'qbx') and resourceStarted('qbx_core') then
        VG.Framework.name = 'qbx'
    end
    if (fw == 'auto' or fw == 'esx') and resourceStarted('es_extended') and VG.Framework.name == 'standalone' then
        pcall(function() VG.Framework.object = exports['es_extended']:getSharedObject(); VG.Framework.name = 'esx' end)
    end
end)

function VG.Framework.GetPlayer(src)
    if VG.Framework.name == 'qb' or VG.Framework.name == 'qbx' then
        local QBCore = VG.Framework.object or exports['qb-core']:GetCoreObject()
        return QBCore and QBCore.Functions.GetPlayer(src)
    end
    if VG.Framework.name == 'esx' then
        local ESX = VG.Framework.object or exports['es_extended']:getSharedObject()
        return ESX and ESX.GetPlayerFromId(src)
    end
end

function VG.Framework.Identifier(src)
    local p = VG.Framework.GetPlayer(src)
    if p and p.PlayerData then return p.PlayerData.citizenid or p.PlayerData.license or tostring(src) end
    if p and p.identifier then return p.identifier end
    return tostring(src)
end



-- Backward compatibility for older server files that still call getPlayerObject().
-- Returns a framework name plus a valid player-like object so prop placement does not break
-- when Config.Framework is standalone but an external inventory is used.
function getPlayerObject(src)
    local player = VG.Framework.GetPlayer(src)
    if player then
        return VG.Framework.name, player
    end

    return VG.Framework.name or 'standalone', {
        source = src,
        identifier = VG.Framework.Identifier(src)
    }
end

function VG.Framework.RegisterUsable(item, cb)
    local fw = (Config.Framework or 'auto'):lower()
    if (fw == 'auto' or fw == 'qb' or fw == 'qbx') and resourceStarted('qb-core') then
        local QBCore = exports['qb-core']:GetCoreObject()
        return QBCore.Functions.CreateUseableItem(item, function(source, itemData) cb(source, itemData) end)
    end
    if (fw == 'auto' or fw == 'esx') and resourceStarted('es_extended') then
        local ESX = exports['es_extended']:getSharedObject()
        if ESX and ESX.RegisterUsableItem then return ESX.RegisterUsableItem(item, function(source, itemData, slot) cb(source, itemData, slot) end) end
    end
end

VG.Inventory = {}
local function invName()
    return ((Config.Inventory or 'auto'):lower()):gsub('_', '-')
end

local function isAutoOr(inv, ...)
    if inv == 'auto' then return true end
    for _, name in ipairs({...}) do
        if inv == name then return true end
    end
    return false
end

local function normalizeItemCount(data)
    if type(data) == 'number' then return data end
    if type(data) ~= 'table' then return 0 end
    if data.amount or data.count then return tonumber(data.amount or data.count) or 0 end
    local total = 0
    for _, item in pairs(data) do
        if type(item) == 'table' then
            total = total + (tonumber(item.amount or item.count or item.quantity) or 0)
        end
    end
    return total
end

local function tryExport(resource, exportName, ...)
    if not resourceStarted(resource) then return false, nil end
    local ok, result = pcall(function(...)
        return exports[resource][exportName](exports[resource], ...)
    end, ...)
    if ok then return true, result end

    ok, result = pcall(function(...)
        return exports[resource][exportName](...)
    end, ...)
    if ok then return true, result end

    return false, nil
end

local function tryExportPacked(resource, exportName, args)
    args = args or {}
    return tryExport(resource, exportName, table.unpack(args, 1, args.n or #args))
end

local function exportWorked(ok, result)
    if not ok then return false end
    if result == false then return false end
    return true
end

local function getPlayerInventoryCount(src, item)
    local player = VG.Framework.GetPlayer(src)
    if player and player.Functions and player.Functions.GetItemByName then
        local data = player.Functions.GetItemByName(item)
        return normalizeItemCount(data)
    end
    if player and player.getInventoryItem then
        return normalizeItemCount(player.getInventoryItem(item))
    end
    return 0
end

function VG.Inventory.GetItemCount(src, item)
    if not item then return 0 end
    local inv = invName()

    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.GetItemCount then
        return tonumber(Config.CustomInventory.GetItemCount(src, item)) or 0
    end

    if isAutoOr(inv, 'ox', 'ox-inventory') and resourceStarted('ox_inventory') then
        local ok, count = pcall(function() return exports.ox_inventory:GetItem(src, item, nil, true) end)
        if ok then return tonumber(count) or 0 end
    end

    if isAutoOr(inv, 'qs', 'qs-inventory') and resourceStarted('qs-inventory') then
        local ok, count = tryExport('qs-inventory', 'GetItemTotalAmount', src, item)
        if ok then return normalizeItemCount(count) end

        ok, count = tryExport('qs-inventory', 'GetItemByName', src, item)
        if ok then return normalizeItemCount(count) end

        ok, count = tryExport('qs-inventory', 'Search', src, 'count', item)
        if ok then return normalizeItemCount(count) end

        ok, count = tryExport('qs-inventory', 'Search', 'count', item)
        if ok then return normalizeItemCount(count) end

        ok, count = tryExport('qs-inventory', 'GetInventory', src)
        if ok and type(count) == 'table' then
            local total = 0
            for _, slot in pairs(count) do
                if type(slot) == 'table' and slot.name == item then
                    total = total + (tonumber(slot.amount or slot.count or slot.quantity) or 0)
                end
            end
            return total
        end
    end

    if isAutoOr(inv, 'qb', 'qb-inventory', 'ps', 'ps-inventory', 'lj', 'lj-inventory') then
        for _, resource in ipairs({ 'qb-inventory', 'ps-inventory', 'lj-inventory' }) do
            if resourceStarted(resource) and (inv == 'auto' or inv == resource or (inv == 'qb' and resource == 'qb-inventory') or (inv == 'ps' and resource == 'ps-inventory') or (inv == 'lj' and resource == 'lj-inventory')) then
                local ok, data = tryExport(resource, 'GetItemByName', src, item)
                if ok then return normalizeItemCount(data) end

                ok, data = tryExport(resource, 'GetItemsByName', src, item)
                if ok then return normalizeItemCount(data) end

                ok, data = tryExport(resource, 'GetInventory', src)
                if ok and type(data) == 'table' then
                    local total = 0
                    for _, slot in pairs(data) do
                        if type(slot) == 'table' and slot.name == item then
                            total = total + (tonumber(slot.amount or slot.count or slot.quantity) or 0)
                        end
                    end
                    return total
                end
            end
        end

        local frameworkCount = getPlayerInventoryCount(src, item)
        if frameworkCount > 0 then return frameworkCount end
    end

    if VG.Framework.name == 'esx' then
        return getPlayerInventoryCount(src, item)
    end

    return getPlayerInventoryCount(src, item)
end

function VG.Inventory.AddItem(src, item, amount, metadata)
    amount = math.max(1, math.floor(tonumber(amount) or 1))
    local inv = invName()

    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.AddItem then
        return Config.CustomInventory.AddItem(src, item, amount, metadata) == true
    end

    if isAutoOr(inv, 'ox', 'ox-inventory') and resourceStarted('ox_inventory') then
        local ok, result = pcall(function() return exports.ox_inventory:AddItem(src, item, amount, metadata) end)
        if ok then return result ~= false end
    end

    if isAutoOr(inv, 'qs', 'qs-inventory') and resourceStarted('qs-inventory') then
        local attempts = {
            table.pack(src, item, amount, nil, metadata),
            table.pack(src, item, amount, false, metadata),
            table.pack(src, item, amount, metadata),
            table.pack(src, item, amount),
        }
        for _, args in ipairs(attempts) do
            local ok, result = tryExportPacked('qs-inventory', 'AddItem', args)
            if exportWorked(ok, result) then return true end
        end
    end

    if isAutoOr(inv, 'qb', 'qb-inventory', 'ps', 'ps-inventory', 'lj', 'lj-inventory') then
        local resources = {
            ['qb-inventory'] = inv == 'auto' or inv == 'qb-inventory' or inv == 'qb',
            ['ps-inventory'] = inv == 'auto' or inv == 'ps-inventory' or inv == 'ps',
            ['lj-inventory'] = inv == 'auto' or inv == 'lj-inventory' or inv == 'lj',
        }
        for resource, allowed in pairs(resources) do
            if allowed and resourceStarted(resource) then
                local attempts = {
                    table.pack(src, item, amount, nil, metadata, 'vg-drugs'),
                    table.pack(src, item, amount, false, metadata, 'vg-drugs'),
                    table.pack(src, item, amount, nil, metadata),
                    table.pack(src, item, amount),
                }
                for _, args in ipairs(attempts) do
                    local ok, result = tryExportPacked(resource, 'AddItem', args)
                    if exportWorked(ok, result) then return true end
                end
            end
        end
    end

    local player = VG.Framework.GetPlayer(src)
    if player and player.Functions and player.Functions.AddItem then
        local ok, result = pcall(function() return player.Functions.AddItem(item, amount, false, metadata) end)
        if ok and result ~= false then return true end
    end
    if player and player.addInventoryItem then
        local ok = pcall(function() player.addInventoryItem(item, amount) end)
        if ok then return true end
    end

    return false
end

function VG.Inventory.RemoveItem(src, item, amount, metadata)
    amount = math.max(1, math.floor(tonumber(amount) or 1))
    local inv = invName()

    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.RemoveItem then
        return Config.CustomInventory.RemoveItem(src, item, amount, metadata) == true
    end

    if isAutoOr(inv, 'ox', 'ox-inventory') and resourceStarted('ox_inventory') then
        local ok, result = pcall(function() return exports.ox_inventory:RemoveItem(src, item, amount, metadata) end)
        if ok then return result ~= false end
    end

    if isAutoOr(inv, 'qs', 'qs-inventory') and resourceStarted('qs-inventory') then
        local attempts = {
            table.pack(src, item, amount, nil, metadata),
            table.pack(src, item, amount, false, metadata),
            table.pack(src, item, amount, metadata),
            table.pack(src, item, amount),
        }
        for _, args in ipairs(attempts) do
            local ok, result = tryExportPacked('qs-inventory', 'RemoveItem', args)
            if exportWorked(ok, result) then return true end
        end
    end

    if isAutoOr(inv, 'qb', 'qb-inventory', 'ps', 'ps-inventory', 'lj', 'lj-inventory') then
        local resources = {
            ['qb-inventory'] = inv == 'auto' or inv == 'qb-inventory' or inv == 'qb',
            ['ps-inventory'] = inv == 'auto' or inv == 'ps-inventory' or inv == 'ps',
            ['lj-inventory'] = inv == 'auto' or inv == 'lj-inventory' or inv == 'lj',
        }
        for resource, allowed in pairs(resources) do
            if allowed and resourceStarted(resource) then
                local attempts = {
                    table.pack(src, item, amount, nil, 'vg-drugs'),
                    table.pack(src, item, amount, false, 'vg-drugs'),
                    table.pack(src, item, amount, nil),
                    table.pack(src, item, amount),
                }
                for _, args in ipairs(attempts) do
                    local ok, result = tryExportPacked(resource, 'RemoveItem', args)
                    if exportWorked(ok, result) then return true end
                end
            end
        end
    end

    local player = VG.Framework.GetPlayer(src)
    if player and player.Functions and player.Functions.RemoveItem then
        local ok, result = pcall(function() return player.Functions.RemoveItem(item, amount, false, metadata) end)
        if ok and result ~= false then return true end
    end
    if player and player.removeInventoryItem then
        local ok = pcall(function() player.removeInventoryItem(item, amount) end)
        if ok then return true end
    end

    return false
end

function VG.Inventory.CanCarry(src, item, amount)
    amount = math.max(1, math.floor(tonumber(amount) or 1))
    local inv = invName()

    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.CanCarry then
        return Config.CustomInventory.CanCarry(src, item, amount) ~= false
    end

    if isAutoOr(inv, 'ox', 'ox-inventory') and resourceStarted('ox_inventory') then
        local ok, result = pcall(function() return exports.ox_inventory:CanCarryItem(src, item, amount) end)
        if ok then return result ~= false end
    end

    if isAutoOr(inv, 'qs', 'qs-inventory') and resourceStarted('qs-inventory') then
        local ok, result = tryExport('qs-inventory', 'CanCarryItem', src, item, amount)
        if ok then return result ~= false end
        ok, result = tryExport('qs-inventory', 'CanCarry', src, item, amount)
        if ok then return result ~= false end
    end

    return true
end

function VG.Inventory.OpenStash(src, stashId, label)
    if resourceStarted('ox_inventory') then
        pcall(function() exports.ox_inventory:RegisterStash(stashId, label or stashId, 50, 100000) end)
        TriggerClientEvent('vg-drugs:client:OpenLabStash', src, stashId, label)
        return true
    end
    TriggerClientEvent('vg-drugs:client:OpenLabStash', src, stashId, label)
    return true
end

lib.callback.register('vg-drugs:server:GetItemCount', function(src, item)
    return VG.Inventory.GetItemCount(src, item)
end)

local function notify(src, type_, description)
    TriggerClientEvent('ox_lib:notify', src, { type = type_ or 'inform', description = description })
end
VG.Notify = notify


VG.Batch = VG.Batch or {}

function VG.Batch.GetLimits(key)
    local limits = Config.BatchProduction and Config.BatchProduction[key] or {}
    local minAmount = math.max(1, math.floor(tonumber(limits.min) or 1))
    local maxAmount = math.max(minAmount, math.floor(tonumber(limits.max) or 1))
    return minAmount, maxAmount
end

function VG.Batch.Validate(src, key, amount)
    local minAmount, maxAmount = VG.Batch.GetLimits(key)
    amount = math.floor(tonumber(amount) or 0)
    if amount < minAmount or amount > maxAmount then
        if src then
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = _L('production_amount_limit', minAmount, maxAmount) })
        end
        return nil
    end
    return amount
end
