VG = VG or {}

local function resourceStarted(name)
    return name and GetResourceState(name) == 'started'
end

VG.Framework = { name = 'standalone', object = nil }
CreateThread(function()
    local fw = (Config.Framework or 'auto'):lower()
    if (fw == 'auto' or fw == 'qb' or fw == 'qbx') and resourceStarted('qb-core') then
        pcall(function() VG.Framework.object = exports['qb-core']:GetCoreObject(); VG.Framework.name = resourceStarted('qbx_core') and 'qbx' or 'qb' end)
    end
    if (fw == 'auto' or fw == 'qbx') and resourceStarted('qbx_core') then
        VG.Framework.name = 'qbx'
    end
    if (fw == 'auto' or fw == 'esx') and resourceStarted('es_extended') and VG.Framework.name == 'standalone' then
        pcall(function() VG.Framework.object = exports['es_extended']:getSharedObject(); VG.Framework.name = 'esx' end)
    end
end)

function VG.Framework.GetPlayer(src)
    if VG.Framework.name == 'qb' or VG.Framework.name == 'qbx' then
        local QBCore = VG.Framework.object or exports['qb-core']:GetCoreObject()
        return QBCore and QBCore.Functions.GetPlayer(src)
    end
    if VG.Framework.name == 'esx' then
        local ESX = VG.Framework.object or exports['es_extended']:getSharedObject()
        return ESX and ESX.GetPlayerFromId(src)
    end
end

function VG.Framework.Identifier(src)
    local p = VG.Framework.GetPlayer(src)
    if p and p.PlayerData then return p.PlayerData.citizenid or p.PlayerData.license or tostring(src) end
    if p and p.identifier then return p.identifier end
    return tostring(src)
end



-- Backward compatibility for older server files that still call getPlayerObject().
-- Returns a framework name plus a valid player-like object so prop placement does not break
-- when Config.Framework is standalone but an external inventory is used.
function getPlayerObject(src)
    local player = VG.Framework.GetPlayer(src)
    if player then
        return VG.Framework.name, player
    end

    return VG.Framework.name or 'standalone', {
        source = src,
        identifier = VG.Framework.Identifier(src)
    }
end

function VG.Framework.RegisterUsable(item, cb)
    local fw = (Config.Framework or 'auto'):lower()
    if (fw == 'auto' or fw == 'qb' or fw == 'qbx') and resourceStarted('qb-core') then
        local QBCore = exports['qb-core']:GetCoreObject()
        return QBCore.Functions.CreateUseableItem(item, function(source, itemData) cb(source, itemData) end)
    end
    if (fw == 'auto' or fw == 'esx') and resourceStarted('es_extended') then
        local ESX = exports['es_extended']:getSharedObject()
        if ESX and ESX.RegisterUsableItem then return ESX.RegisterUsableItem(item, function(source, itemData, slot) cb(source, itemData, slot) end) end
    end
end

VG.Inventory = {}
local function invName() return (Config.Inventory or 'auto'):lower() end

function VG.Inventory.GetItemCount(src, item)
    if not item then return 0 end
    local inv = invName()
    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.GetItemCount then return Config.CustomInventory.GetItemCount(src, item) or 0 end
    if (inv == 'auto' or inv == 'ox' or inv == 'ox_inventory') and resourceStarted('ox_inventory') then
        return exports.ox_inventory:GetItem(src, item, nil, true) or 0
    end
    if (inv == 'auto' or inv == 'qs' or inv == 'qs-inventory') and resourceStarted('qs-inventory') then
        local ok, count = pcall(function() return exports['qs-inventory']:GetItemTotalAmount(src, item) end)
        if ok then return tonumber(count) or 0 end
    end
    if (inv == 'auto' or inv == 'qb' or inv == 'qb-inventory' or inv == 'ps' or inv == 'ps-inventory' or inv == 'lj' or inv == 'lj-inventory') then
        local player = VG.Framework.GetPlayer(src)
        if player and player.Functions and player.Functions.GetItemByName then
            local data = player.Functions.GetItemByName(item)
            return data and (data.amount or data.count) or 0
        end
    end
    if VG.Framework.name == 'esx' then
        local player = VG.Framework.GetPlayer(src)
        local itemData = player and player.getInventoryItem and player.getInventoryItem(item)
        return itemData and (itemData.count or itemData.amount) or 0
    end
    return 0
end

function VG.Inventory.AddItem(src, item, amount, metadata)
    amount = tonumber(amount) or 1
    local inv = invName()
    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.AddItem then return Config.CustomInventory.AddItem(src, item, amount, metadata) end
    if (inv == 'auto' or inv == 'ox' or inv == 'ox_inventory') and resourceStarted('ox_inventory') then
        return exports.ox_inventory:AddItem(src, item, amount, metadata)
    end
    if (inv == 'auto' or inv == 'qs' or inv == 'qs-inventory') and resourceStarted('qs-inventory') then
        return exports['qs-inventory']:AddItem(src, item, amount, false, metadata)
    end
    local player = VG.Framework.GetPlayer(src)
    if player and player.Functions and player.Functions.AddItem then return player.Functions.AddItem(item, amount, false, metadata) end
    if player and player.addInventoryItem then player.addInventoryItem(item, amount); return true end
    return false
end

function VG.Inventory.RemoveItem(src, item, amount, metadata)
    amount = tonumber(amount) or 1
    local inv = invName()
    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.RemoveItem then return Config.CustomInventory.RemoveItem(src, item, amount, metadata) end
    if (inv == 'auto' or inv == 'ox' or inv == 'ox_inventory') and resourceStarted('ox_inventory') then
        return exports.ox_inventory:RemoveItem(src, item, amount, metadata)
    end
    if (inv == 'auto' or inv == 'qs' or inv == 'qs-inventory') and resourceStarted('qs-inventory') then
        return exports['qs-inventory']:RemoveItem(src, item, amount, false, metadata)
    end
    local player = VG.Framework.GetPlayer(src)
    if player and player.Functions and player.Functions.RemoveItem then return player.Functions.RemoveItem(item, amount, false, metadata) end
    if player and player.removeInventoryItem then player.removeInventoryItem(item, amount); return true end
    return false
end

function VG.Inventory.CanCarry(src, item, amount)
    local inv = invName()
    if inv == 'custom' and Config.CustomInventory and Config.CustomInventory.CanCarry then return Config.CustomInventory.CanCarry(src, item, amount or 1) end
    if (inv == 'auto' or inv == 'ox' or inv == 'ox_inventory') and resourceStarted('ox_inventory') then
        return exports.ox_inventory:CanCarryItem(src, item, amount or 1)
    end
    return true
end

function VG.Inventory.OpenStash(src, stashId, label)
    if resourceStarted('ox_inventory') then
        pcall(function() exports.ox_inventory:RegisterStash(stashId, label or stashId, 50, 100000) end)
        TriggerClientEvent('vg-drugs:client:OpenLabStash', src, stashId, label)
        return true
    end
    TriggerClientEvent('vg-drugs:client:OpenLabStash', src, stashId, label)
    return true
end

lib.callback.register('vg-drugs:server:GetItemCount', function(src, item)
    return VG.Inventory.GetItemCount(src, item)
end)

local function notify(src, type_, description)
    TriggerClientEvent('ox_lib:notify', src, { type = type_ or 'inform', description = description })
end
VG.Notify = notify


VG.Batch = VG.Batch or {}

function VG.Batch.GetLimits(key)
    local limits = Config.BatchProduction and Config.BatchProduction[key] or {}
    local minAmount = math.max(1, math.floor(tonumber(limits.min) or 1))
    local maxAmount = math.max(minAmount, math.floor(tonumber(limits.max) or 1))
    return minAmount, maxAmount
end

function VG.Batch.Validate(src, key, amount)
    local minAmount, maxAmount = VG.Batch.GetLimits(key)
    amount = math.floor(tonumber(amount) or 0)
    if amount < minAmount or amount > maxAmount then
        if src then
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = _L('production_amount_limit', minAmount, maxAmount) })
        end
        return nil
    end
    return amount
end
