local interactedNPCs = {}

RegisterNetEvent('vg-drugs:server:SellToNPC', function(netId, itemName, amount)
    local src = source
    local itemConfig = Config.NPC.SellableDrugs[itemName]

    if not itemConfig then return end

    if interactedNPCs[netId] then
        return TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You already spoke to this person. They are not interested anymore.' })
    end

    local haveItem = exports.ox_inventory:GetItem(src, itemName, nil, true) or 0
    if haveItem < amount then
        return TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You do not have that much product on you.' })
    end

    local pricePerItem = math.random(itemConfig.minPrice, itemConfig.maxPrice)
    local totalMoney = pricePerItem * amount

    interactedNPCs[netId] = true

    exports.ox_inventory:RemoveItem(src, itemName, amount)
    exports.ox_inventory:AddItem(src, Config.NPC.MoneyItem, totalMoney)

    TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = ('The customer bought %sx %s and paid you $%s.'):format(amount, itemConfig.label, totalMoney) })
end)

CreateThread(function()
    while true do
        Wait(1000 * 60 * (Config.NPC.Cooldown or 30))
        interactedNPCs = {}
    end
end)
