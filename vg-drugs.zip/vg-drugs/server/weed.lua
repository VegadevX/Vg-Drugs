-- Framework and usable-item handling is provided by server/bridge/framework.lua.
local function getPlayerIdentifier(src)
    return VG.Framework.Identifier(src)
end

local function registerUsable(itemName, cb)
    return VG.Framework.RegisterUsable(itemName, cb)
end

local ServerProps = {}
local HasBucketColumn = false
local HasCaravanColumn = false

local function notify(src, type_, description)
    TriggerClientEvent('ox_lib:notify', src, {
        type = type_,
        description = description
    })
end

local function getModelForType(propType)
    if propType == 'weed_table' then return Config.Weed.Props.table end
    if propType == 'weed_pot' then return Config.Weed.Props.pot end
    if propType == 'grow_light' then return Config.Weed.Props.light end
    if propType == 'coke_table' then return Config.Coke.Props.table end
    if propType == 'meth_table' then return Config.Meth.Props.table end
end

local function getActiveLabState(src)
    return VGDrugLabs and VGDrugLabs.GetActiveLabState and VGDrugLabs.GetActiveLabState(src) or nil
end

local function getScopeForPlayer(src)
    local bucket = GetPlayerRoutingBucket(src) or 0
    local activeLab = getActiveLabState(src)

    return {
        bucket = bucket,
        caravanId = activeLab and activeLab.plate or nil
    }
end

local function canPlayerAccessProp(src, prop)
    local scope = getScopeForPlayer(src)

    if (prop.caravanId or nil) ~= (scope.caravanId or nil) then
        return false
    end

    return (prop.bucket or 0) == (scope.bucket or 0)
end

local function getPlayersForProp(prop)
    local players = {}

    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        if canPlayerAccessProp(src, prop) then
            players[#players + 1] = src
        end
    end

    return players
end

local function triggerPropScope(eventName, prop, ...)
    for _, src in ipairs(getPlayersForProp(prop)) do
        TriggerClientEvent(eventName, src, ...)
    end
end

local function savePropData(id, prop)
    local safeData = prop.data or {}

    if HasBucketColumn and HasCaravanColumn then
        exports.oxmysql:update(
            'UPDATE vg_drug_props SET data = ?, bucket = ?, caravan_id = ? WHERE id = ?',
            { json.encode(safeData), prop.bucket or 0, prop.caravanId, id }
        )
    elseif HasBucketColumn then
        exports.oxmysql:update(
            'UPDATE vg_drug_props SET data = ?, bucket = ? WHERE id = ?',
            { json.encode(safeData), prop.bucket or 0, id }
        )
    else
        exports.oxmysql:update(
            'UPDATE vg_drug_props SET data = ? WHERE id = ?',
            { json.encode(safeData), id }
        )
    end
end

local function getGrowthSeconds(hasLight)
    local growth = Config.Weed.Growth or {}

    if growth.UseTestTime then
        return hasLight and (growth.TestLightSeconds or 90) or (growth.TestNormalSeconds or 180)
    end

    return hasLight and (growth.LightSeconds or 9000) or (growth.NormalSeconds or 14400)
end

local function getNow()
    return os.time()
end

local function getRemainingSeconds(prop)
    local finishAt = prop and prop.data and prop.data.finish_at or 0
    return math.max(0, finishAt - getNow())
end

local function updatePlantTimerForLight(prop, hasLight)
    if not prop or not prop.data or not prop.data.planted then return end

    local oldHasLight = prop.data.has_light or false
    local now = getNow()
    local oldTotal = getGrowthSeconds(oldHasLight)
    local newTotal = getGrowthSeconds(hasLight)
    local currentFinishAt = prop.data.finish_at or (now + oldTotal)

    local remaining = math.max(0, currentFinishAt - now)
    local progress = 1.0 - (remaining / oldTotal)

    if progress < 0.0 then progress = 0.0 end
    if progress > 1.0 then progress = 1.0 end

    local newRemaining = math.floor(newTotal * (1.0 - progress))

    prop.data.has_light = hasLight
    prop.data.finish_at = now + newRemaining
end

local function updatePlantStageFromTimer(prop)
    if not prop or not prop.data or not prop.data.planted then return end

    local total = getGrowthSeconds(prop.data.has_light or false)
    local remaining = getRemainingSeconds(prop)
    local elapsed = math.max(0, total - remaining)
    local ratio = elapsed / total

    local newStage = 0

    if ratio >= 1.0 then
        newStage = 3
    elseif ratio >= 0.66 then
        newStage = 2
    elseif ratio >= 0.33 then
        newStage = 1
    end

    prop.data.stage = newStage
end

local function canPlacePropInScope(src, coords, propType)
    local scope = getScopeForPlayer(src)
    local target = vec3(coords.x, coords.y, coords.z)

    for _, prop in pairs(ServerProps) do
        if (prop.bucket or 0) == scope.bucket and (prop.caravanId or nil) == (scope.caravanId or nil) then
            if prop.coords and prop.coords.x then
                local dist = #(vec3(prop.coords.x, prop.coords.y, prop.coords.z) - target)
                local clearance = (Config.Weed.Placement and Config.Weed.Placement.minClearance or 0.65)

                if prop.type == propType then
                    clearance = clearance + 0.15
                end

                if dist < clearance then
                    return false
                end
            end
        end
    end

    return true
end

local function broadcastSpawn(id, targetSrc)
    local prop = ServerProps[id]
    if not prop or not prop.coords or not prop.coords.x then return end

    if targetSrc then
        if canPlayerAccessProp(targetSrc, prop) then
            TriggerClientEvent(
                'vg-drugs:client:SpawnProp',
                targetSrc,
                id,
                getModelForType(prop.type),
                prop.type,
                prop.coords,
                prop.coords.h or 0.0,
                prop.data or {}
            )
        end
        return
    end

    triggerPropScope(
        'vg-drugs:client:SpawnProp',
        prop,
        id,
        getModelForType(prop.type),
        prop.type,
        prop.coords,
        prop.coords.h or 0.0,
        prop.data or {}
    )
end

local function loadProps()
    local selectQuery

    if HasBucketColumn and HasCaravanColumn then
        selectQuery = 'SELECT id, owner, type, bucket, caravan_id, coords, data FROM vg_drug_props'
    elseif HasBucketColumn then
        selectQuery = 'SELECT id, owner, type, bucket, NULL AS caravan_id, coords, data FROM vg_drug_props'
    else
        selectQuery = 'SELECT id, owner, type, 0 AS bucket, NULL AS caravan_id, coords, data FROM vg_drug_props'
    end

    exports.oxmysql:query(selectQuery, {}, function(result)
        ServerProps = {}

        for _, row in ipairs(result or {}) do
            local okCoords, coords = pcall(json.decode, row.coords or '{}')
            if not okCoords or type(coords) ~= 'table' then coords = {} end

            local okData, data = pcall(json.decode, row.data or '{}')
            if not okData or type(data) ~= 'table' then data = {} end

            if coords.x and coords.y and coords.z then
                ServerProps[row.id] = {
                    id = row.id,
                    owner = row.owner,
                    type = row.type,
                    bucket = row.bucket or 0,
                    caravanId = row.caravan_id,
                    coords = coords,
                    data = data
                }
            else
                print('^3[VG-Drugs]^7 ID ' .. row.id .. ' contains invalid coordinates and was skipped.')
            end
        end

        print(('^2[VG-Drugs]^7 %s prop(s) loaded.'):format(#(result or {})))
    end)
end

CreateThread(function()
    Wait(1500)

    exports.oxmysql:query("SHOW COLUMNS FROM vg_drug_props LIKE 'bucket'", {}, function(result)
        HasBucketColumn = result and result[1] ~= nil

        if not HasBucketColumn then
            exports.oxmysql:query(
                'ALTER TABLE vg_drug_props ADD COLUMN bucket INT NOT NULL DEFAULT 0 AFTER type',
                {},
                function() end
            )
            HasBucketColumn = true
        end

        exports.oxmysql:query("SHOW COLUMNS FROM vg_drug_props LIKE 'caravan_id'", {}, function(result2)
            HasCaravanColumn = result2 and result2[1] ~= nil

            if not HasCaravanColumn then
                exports.oxmysql:query(
                    'ALTER TABLE vg_drug_props ADD COLUMN caravan_id VARCHAR(20) NULL DEFAULT NULL AFTER bucket',
                    {},
                    function() end
                )
                HasCaravanColumn = true
            end

            exports.oxmysql:query('CREATE INDEX IF NOT EXISTS idx_vg_drug_props_bucket ON vg_drug_props (bucket)', {}, function() end)
            exports.oxmysql:query('CREATE INDEX IF NOT EXISTS idx_vg_drug_props_caravan ON vg_drug_props (caravan_id)', {}, function() end)

            Wait(250)
            loadProps()
        end)
    end)
end)

registerUsable(Config.Weed.Items.table, function(source)
    TriggerClientEvent('vg-drugs:client:UseItem', source, { type = 'weed_table' })
end)

registerUsable(Config.Weed.Items.pot, function(source)
    TriggerClientEvent('vg-drugs:client:UseItem', source, { type = 'pot' })
end)

registerUsable(Config.Weed.Items.light, function(source)
    TriggerClientEvent('vg-drugs:client:UseItem', source, { type = 'light' })
end)

RegisterNetEvent('vg-drugs:server:SaveProp', function(model, propType, coords, heading, itemName)
    local src = source
    local _, player = getPlayerObject(src)

    if not player then return end
    if type(coords) ~= 'table' or not coords.x then return end

    if not canPlacePropInScope(src, coords, propType) then
        return notify(src, 'error', _L('prop_too_close'))
    end

    if not VG.Inventory.RemoveItem(src, itemName, 1) then
        return notify(src, 'error', _L('missing_item'))
    end

    local data = {}

    if propType == 'weed_pot' then
        data = {
            stage = 0,
            water = 0,
            has_light = false,
            planted = false,
            fertilized = false,
            planted_time = 0,
            finish_at = 0
        }
    end

    local scope = getScopeForPlayer(src)
    local coordsData = {
        x = coords.x,
        y = coords.y,
        z = coords.z,
        h = heading
    }

    local insertQuery
    local insertParams

    if HasBucketColumn and HasCaravanColumn then
        insertQuery = 'INSERT INTO vg_drug_props (owner, type, bucket, caravan_id, coords, data) VALUES (?, ?, ?, ?, ?, ?)'
        insertParams = {
            getPlayerIdentifier(src),
            propType,
            scope.bucket,
            scope.caravanId,
            json.encode(coordsData),
            json.encode(data)
        }
    elseif HasBucketColumn then
        insertQuery = 'INSERT INTO vg_drug_props (owner, type, bucket, coords, data) VALUES (?, ?, ?, ?, ?)'
        insertParams = {
            getPlayerIdentifier(src),
            propType,
            scope.bucket,
            json.encode(coordsData),
            json.encode(data)
        }
    else
        insertQuery = 'INSERT INTO vg_drug_props (owner, type, coords, data) VALUES (?, ?, ?, ?)'
        insertParams = {
            getPlayerIdentifier(src),
            propType,
            json.encode(coordsData),
            json.encode(data)
        }
    end

    exports.oxmysql:insert(insertQuery, insertParams, function(insertId)
        ServerProps[insertId] = {
            id = insertId,
            owner = getPlayerIdentifier(src),
            type = propType,
            bucket = scope.bucket,
            caravanId = scope.caravanId,
            coords = coordsData,
            data = data
        }

        broadcastSpawn(insertId)
        notify(src, 'success', _L('place_success'))
    end)
end)

RegisterNetEvent('vg-drugs:server:RequestProps', function()
    local src = source
    local scope = getScopeForPlayer(src)

    TriggerClientEvent('vg-drugs:client:RemoveAllProps', src)

    for id, prop in pairs(ServerProps) do
        if (prop.bucket or 0) == scope.bucket and (prop.caravanId or nil) == (scope.caravanId or nil) then
            if prop.coords and prop.coords.x then
                TriggerClientEvent(
                    'vg-drugs:client:SpawnProp',
                    src,
                    id,
                    getModelForType(prop.type),
                    prop.type,
                    prop.coords,
                    prop.coords.h or 0.0,
                    prop.data or {}
                )
            end
        end
    end
end)

RegisterNetEvent('vg-drugs:server:PickupProp', function(id, propType)
    local src = source
    local prop = ServerProps[id]

    if not prop or prop.type ~= propType then return end
    if not canPlayerAccessProp(src, prop) then return end

    local itemName = ({
        weed_table = Config.Weed.Items.table,
        weed_pot = Config.Weed.Items.pot,
        grow_light = Config.Weed.Items.light,
        coke_table = Config.Coke.Items.table,
        meth_table = Config.Meth.Items.table,
    })[propType]

    if not itemName then return end

    if propType == 'weed_pot' and prop.data and prop.data.planted then
        return notify(src, 'error', _L('cannot_pickup_planted'))
    end

    if VG.Inventory.AddItem(src, itemName, 1) then
        exports.oxmysql:execute('DELETE FROM vg_drug_props WHERE id = ?', { id })
        ServerProps[id] = nil
        triggerPropScope('vg-drugs:client:RemoveProp', prop, id)
        notify(src, 'success', _L('picked_up'))
    else
        notify(src, 'error', _L('no_inventory_space'))
    end
end)

RegisterNetEvent('vg-drugs:server:PotAction', function(id, action)
    local src = source
    local prop = ServerProps[id]

    if not prop or prop.type ~= 'weed_pot' then return end
    if not canPlayerAccessProp(src, prop) then return end

    prop.data = prop.data or {
        stage = 0,
        water = 0,
        has_light = false,
        planted = false,
        fertilized = false,
        planted_time = 0,
        finish_at = 0
    }

    if action == 'fertilize' then
        if prop.data.fertilized then
            return notify(src, 'error', 'This pot is already fertilized.')
        end

        if (VG.Inventory.GetItemCount(src, Config.Weed.Items.fertilizer, nil, true) or 0) < 1 then
            return notify(src, 'error', 'You do not have fertilizer.')
        end

        VG.Inventory.RemoveItem(src, Config.Weed.Items.fertilizer, 1)
        prop.data.fertilized = true
        savePropData(id, prop)
        triggerPropScope('vg-drugs:client:UpdateProp', prop, id, prop.data)
        notify(src, 'success', 'You fertilized the pot and prepared the soil for planting.')

    elseif action == 'plant' then
        if prop.data.planted then
            return notify(src, 'error', 'There is already a planted crop in this pot.')
        end

        if not prop.data.fertilized then
            return notify(src, 'error', 'You need to fertilize the pot first.')
        end

        if (VG.Inventory.GetItemCount(src, Config.Weed.Items.seed, nil, true) or 0) < 1 then
            return notify(src, 'error', 'Tohumun yok.')
        end

        VG.Inventory.RemoveItem(src, Config.Weed.Items.seed, 1)

        local now = getNow()
        local totalSeconds = getGrowthSeconds(false)

        prop.data.planted = true
        prop.data.planted_time = now
        prop.data.finish_at = now + totalSeconds
        prop.data.has_light = false
        prop.data.stage = 0
        prop.data.water = math.max(prop.data.water or 0, 35)

        savePropData(id, prop)
        triggerPropScope('vg-drugs:client:UpdateProp', prop, id, prop.data)
        notify(src, 'success', 'Tohum ekildi.')

    elseif action == 'water' then
        if not prop.data.planted then
            return notify(src, 'error', 'You need to plant a seed first.')
        end

        if (VG.Inventory.GetItemCount(src, Config.Weed.Items.water, nil, true) or 0) < 1 then
            return notify(src, 'error', 'Suyun yok.')
        end

        VG.Inventory.RemoveItem(src, Config.Weed.Items.water, 1)
        prop.data.water = 100

        savePropData(id, prop)
        triggerPropScope('vg-drugs:client:UpdateProp', prop, id, prop.data)
        notify(src, 'success', 'You watered the plant.')

    elseif action == 'harvest' then
        if not prop.data.planted or (prop.data.stage or 0) < 3 then
            return notify(src, 'error', 'This plant is not ready to harvest yet.')
        end

        local yieldAmount = math.random(Config.Weed.Yield.min, Config.Weed.Yield.max)
        if math.random(1, 100) <= Config.Weed.Chances.extraYield then
            yieldAmount = yieldAmount + 1
        end

        VG.Inventory.AddItem(src, Config.Weed.Items.raw, yieldAmount)

        if math.random(1, 100) <= Config.Weed.Chances.returnSeed then
            VG.Inventory.AddItem(src, Config.Weed.Items.seed, 1)
        end

        prop.data = {
            stage = 0,
            water = 0,
            has_light = false,
            planted = false,
            fertilized = false,
            planted_time = 0,
            finish_at = 0
        }

        savePropData(id, prop)
        triggerPropScope('vg-drugs:client:UpdateProp', prop, id, prop.data)
        notify(src, 'success', ('Harvest complete. You received %sx product.'):format(yieldAmount))
    end
end)

RegisterNetEvent('vg-drugs:server:DestroyWeedPlant', function(id)
    local src = source
    local prop = ServerProps[id]

    if not prop or prop.type ~= 'weed_pot' then return end
    if not canPlayerAccessProp(src, prop) then return end

    exports.oxmysql:execute('DELETE FROM vg_drug_props WHERE id = ?', { id })
    ServerProps[id] = nil
    TriggerClientEvent('vg-drugs:client:RemoveProp', -1, id)
    notify(src, 'success', 'The plant and pot were permanently destroyed.')
end)

CreateThread(function()
    while true do
        Wait(60000)

        local lightByScope = {}

        for _, prop in pairs(ServerProps) do
            if prop.type == 'grow_light' and prop.coords and prop.coords.x then
                local key = ('%s:%s'):format(prop.bucket or 0, prop.caravanId or 'global')
                lightByScope[key] = lightByScope[key] or {}
                lightByScope[key][#lightByScope[key] + 1] = vec3(prop.coords.x, prop.coords.y, prop.coords.z)
            end
        end

        for id, prop in pairs(ServerProps) do
            if prop.type == 'weed_pot' and prop.data and prop.data.planted and (prop.data.stage or 0) < 3 then
                if prop.coords and prop.coords.x then
                    local potCoord = vec3(prop.coords.x, prop.coords.y, prop.coords.z)
                    local scopeKey = ('%s:%s'):format(prop.bucket or 0, prop.caravanId or 'global')
                    local bucketLights = lightByScope[scopeKey] or {}

                    local detectedLight = false
                    for _, lightCoord in ipairs(bucketLights) do
                        if #(potCoord - lightCoord) < 15.0 then
                            detectedLight = true
                            break
                        end
                    end

                    local oldStage = prop.data.stage or 0
                    local oldHasLight = prop.data.has_light or false
                    local oldWater = prop.data.water or 0

                    updatePlantTimerForLight(prop, detectedLight)

                    prop.data.water = math.max(0, oldWater - (100 / Config.Weed.Times.waterDepletion))

                    if (prop.data.water or 0) > 0 then
                        updatePlantStageFromTimer(prop)
                    end

                    local changed =
                        (oldStage ~= (prop.data.stage or 0)) or
                        (oldHasLight ~= (prop.data.has_light or false)) or
                        (math.floor(oldWater) ~= math.floor(prop.data.water or 0))

                    savePropData(id, prop)

                    if changed then
                        triggerPropScope('vg-drugs:client:UpdateProp', prop, id, prop.data)
                    end
                end
            end
        end
    end
end)

RegisterNetEvent('vg-drugs:server:ProcessWeed', function(processType, amount)
    local src = source
    if processType == 'pack' then
        amount = VG.Batch.Validate(src, 'weed_pack', amount)
        if not amount then return end
        local reqPack = Config.Weed.Processing.PackRawRequired * amount
        local rawItem = VG.Inventory.GetItemCount(src, Config.Weed.Items.raw) or 0
        local bagItem = VG.Inventory.GetItemCount(src, Config.Weed.Items.bag) or 0

        if rawItem < reqPack or bagItem < amount then
            return notify(src, 'error', _L('need_pack_requirements_count', Config.Weed.Processing.PackRawRequired))
        end

        if math.random(1, 100) <= Config.Weed.Chances.failProcess then
            return notify(src, 'error', _L('packaging_failed'))
        end

        VG.Inventory.RemoveItem(src, Config.Weed.Items.raw, reqPack)
        VG.Inventory.RemoveItem(src, Config.Weed.Items.bag, amount)
        VG.Inventory.AddItem(src, Config.Weed.Items.packed, amount)

        return notify(src, 'success', _L('packed_batch_success', amount))

    elseif processType == 'joint' then
        amount = VG.Batch.Validate(src, 'weed_joint', amount)
        if not amount then return end
        local reqJoint = Config.Weed.Processing.JointRawRequired * amount
        local rawItem = VG.Inventory.GetItemCount(src, Config.Weed.Items.raw) or 0

        if rawItem < reqJoint then
            return notify(src, 'error', _L('need_joint_requirements_count', Config.Weed.Processing.JointRawRequired))
        end

        VG.Inventory.RemoveItem(src, Config.Weed.Items.raw, reqJoint)
        VG.Inventory.AddItem(src, Config.Weed.Items.joint, amount)

        return notify(src, 'success', _L('rolled_batch_success', amount))
    end
end)

lib.callback.register('vg-drugs:server:GetPlantStatus', function(src, id)
    local prop = ServerProps[id]

    if not prop or prop.type ~= 'weed_pot' then
        return nil
    end

    if not canPlayerAccessProp(src, prop) then
        return nil
    end

    prop.data = prop.data or {
        stage = 0,
        water = 0,
        has_light = false,
        planted = false,
        fertilized = false,
        planted_time = 0,
        finish_at = 0
    }

    local oldStage = prop.data.stage or 0
    local oldHasLight = prop.data.has_light or false

    if prop.coords and prop.coords.x then
        local potCoord = vec3(prop.coords.x, prop.coords.y, prop.coords.z)
        local detectedLight = false

        for _, otherProp in pairs(ServerProps) do
            if otherProp.type == 'grow_light' and otherProp.coords and otherProp.coords.x then
                if (otherProp.bucket or 0) == (prop.bucket or 0) and (otherProp.caravanId or nil) == (prop.caravanId or nil) then
                    local lightCoord = vec3(otherProp.coords.x, otherProp.coords.y, otherProp.coords.z)
                    if #(potCoord - lightCoord) < 15.0 then
                        detectedLight = true
                        break
                    end
                end
            end
        end

        updatePlantTimerForLight(prop, detectedLight)
    end

    updatePlantStageFromTimer(prop)

    local newStage = prop.data.stage or 0

    if oldStage ~= newStage or oldHasLight ~= prop.data.has_light then
        savePropData(id, prop)
        triggerPropScope('vg-drugs:client:UpdateProp', prop, id, prop.data)
    end

    local yesText = (_L and _L('yes')) or 'Var'
    local noText = (_L and _L('no')) or 'Yok'

    local waterPercent = math.floor(prop.data.water or 0)
    local waterDepletionRate = Config.Weed.Times.waterDepletion or 50
    local waterSecondsLeft = math.floor((waterPercent / 100) * waterDepletionRate * 60)

    return {
        fertilized = prop.data.fertilized and yesText or noText,
        planted = prop.data.planted and yesText or noText,
        stage = ('%s/3'):format(newStage),
        water = ('%s%%'):format(waterPercent),
        water_seconds = waterSecondsLeft,
        light = (prop.data.has_light and yesText or noText),
        remaining = getRemainingSeconds(prop)
    }
end)
