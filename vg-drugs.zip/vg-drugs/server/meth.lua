local FrameworkName = Config.Framework or 'auto'
local QBCore, ESX = nil, nil
if FrameworkName == 'auto' or FrameworkName == 'qb' or FrameworkName == 'qbx' then pcall(function() QBCore = exports['qb-core']:GetCoreObject() end) end
if FrameworkName == 'auto' or FrameworkName == 'esx' then pcall(function() ESX = exports['es_extended']:getSharedObject() end) end
local function getPlayerObject(src)
    if QBCore then return 'qb', QBCore.Functions.GetPlayer(src) end
    if ESX then return 'esx', ESX.GetPlayerFromId(src) end
    return nil, nil
end
local function getPlayerIdentifier(src)
    local fw, player = getPlayerObject(src)
    if fw == 'qb' and player then return player.PlayerData.citizenid or player.PlayerData.license or tostring(src) end
    if fw == 'esx' and player then return player.identifier or tostring(src) end
    return tostring(src)
end
local function registerUsable(itemName, cb)
    if QBCore then return QBCore.Functions.CreateUseableItem(itemName, function(source, item) cb(source, item) end) end
    if ESX and ESX.RegisterUsableItem then return ESX.RegisterUsableItem(itemName, function(source, item, slot) cb(source, item, slot) end) end
end
local ActiveLabs = {}
local VehicleLabs = {}
local PlateLabStates = {}
local updatePlateVehicleState

VGDrugLabs = VGDrugLabs or {}

local function hasSetupItems(src)
    local items = Config.CaravanLabs and Config.CaravanLabs.setupItems or {}
    for itemName, itemCount in pairs(items) do
        if (exports.ox_inventory:GetItem(src, itemName, nil, true) or 0) < itemCount then
            return false, itemName, itemCount
        end
    end
    return true
end

local function consumeSetupItems(src)
    local items = Config.CaravanLabs and Config.CaravanLabs.setupItems or {}
    for itemName, itemCount in pairs(items) do
        exports.ox_inventory:RemoveItem(src, itemName, itemCount)
    end
end

local function notify(src, type_, description) TriggerClientEvent('ox_lib:notify', src, { type = type_, description = description }) end
local function trimPlate(plate) return (plate or ''):gsub('^%s*(.-)%s*$', '%1') end

local function getAllVehiclesSafe()
    local ok, vehicles = pcall(GetAllVehicles)
    if ok and vehicles then return vehicles end
    return {}
end

local function getEntityFromNetIdSafe(netId)
    if not netId or netId == 0 then return nil end
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, netId)
    if not ok or not ent or ent == 0 then return nil end
    if not DoesEntityExist(ent) then return nil end
    return ent
end

local function getNetIdFromEntitySafe(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return 0 end
    local ok, netId = pcall(NetworkGetNetworkIdFromEntity, entity)
    if not ok or not netId then return 0 end
    return netId
end

local function findVehicleByPlate(plate)
    plate = trimPlate(plate)
    if plate == '' then return nil end
    local vehicles = getAllVehiclesSafe()
    for i = 1, #vehicles do
        local veh = vehicles[i]
        if veh and veh ~= 0 and DoesEntityExist(veh) and trimPlate(GetVehicleNumberPlateText(veh)) == plate then return veh end
    end
    return nil
end

local function findNearestCamper(coords, radius)
    if not coords then return nil end
    radius = radius or 12.0
    local camperModel = joaat(Config.Meth.Props.camper)
    local vehicles = getAllVehiclesSafe()
    local closestVeh, closestDist = nil, nil
    for i = 1, #vehicles do
        local veh = vehicles[i]
        if veh and veh ~= 0 and DoesEntityExist(veh) and GetEntityModel(veh) == camperModel then
            local dist = #(GetEntityCoords(veh) - coords)
            if dist <= radius and (not closestDist or dist < closestDist) then
                closestVeh = veh
                closestDist = dist
            end
        end
    end
    return closestVeh
end

local function resolveVehicle(vehicleNetId, plate, fallbackCoords)
    local vehicle = getEntityFromNetIdSafe(vehicleNetId)
    if vehicle then return vehicle end
    if plate and plate ~= '' then
        vehicle = findVehicleByPlate(plate)
        if vehicle then return vehicle end
    end
    if fallbackCoords then
        local coords = vector3(fallbackCoords.x, fallbackCoords.y, fallbackCoords.z)
        vehicle = findNearestCamper(coords, 14.0)
        if vehicle then return vehicle end
    end
    return nil
end

local function getStateVehicle(state)
    if not state then return nil end
    local vehicle = resolveVehicle(state.vehicleNetId, state.plate, state.lastCoords)
    if vehicle then
        local netId = getNetIdFromEntitySafe(vehicle)
        if netId and netId ~= 0 then state.vehicleNetId = netId end
        local coords = GetEntityCoords(vehicle)
        state.lastCoords = { x = coords.x, y = coords.y, z = coords.z }
        state.lastHeading = GetEntityHeading(vehicle)
        state.plate = trimPlate(GetVehicleNumberPlateText(vehicle))
        return vehicle
    end
    return nil
end

local function getBestLabDispatchCoords(src)
    local state = ActiveLabs[src]
    if state then
        local vehicle = resolveVehicle(state.vehicleNetId, state.plate, state.lastCoords)
        if vehicle and DoesEntityExist(vehicle) then
            local coords = GetEntityCoords(vehicle)
            local heading = GetEntityHeading(vehicle)
            updatePlateVehicleState(state.plate, { x = coords.x, y = coords.y, z = coords.z }, heading, getNetIdFromEntitySafe(vehicle))
            state.lastCoords = { x = coords.x, y = coords.y, z = coords.z }
            state.lastHeading = heading
            return vector3(coords.x, coords.y, coords.z)
        end
        local plateState = state.plate and PlateLabStates[state.plate]
        if plateState and plateState.currentCoords then return vector3(plateState.currentCoords.x, plateState.currentCoords.y, plateState.currentCoords.z) end
        if state.lastCoords then return vector3(state.lastCoords.x, state.lastCoords.y, state.lastCoords.z) end
    end
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then return GetEntityCoords(ped) end
    return nil
end

local function sendConfiguredDispatch(src, coords, code, message)
    if not coords then return end
    local dispatchCfg = Config and Config.Dispatch or {}
    if dispatchCfg.enabled == false then return end

    local payload = {
        message = message or 'Drug lab alert',
        codeName = code or 'druglab',
        code = code or '10-80',
        dispatchCode = code or '10-80',
        description = message or 'Drug lab alert',
        information = message or 'Drug lab alert',
        coords = { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 },
        forceCoords = { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 },
        caravanCoords = { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 },
        originSource = src,
        jobs = dispatchCfg.jobs or { 'leo', 'police' }
    }

    local provider = (dispatchCfg.provider or 'ps-dispatch'):lower()
    if provider == 'ps-dispatch' then
        TriggerEvent('ps-dispatch:server:notify', payload)
        return
    elseif provider == 'sento-dispatch' then
        TriggerEvent('sento-dispatch:server:notify', payload)
        return
    end
    TriggerEvent('ps-dispatch:server:notify', payload)
    TriggerEvent('sento-dispatch:server:notify', payload)
end


exports('GetPlayerDrugLabDispatchCoords', function(src)
    return getBestLabDispatchCoords(src)
end)

exports('GetPlateDrugLabDispatchCoords', function(plate)
    plate = trimPlate(plate)
    if plate == '' then return nil end

    local vehicle = findVehicleByPlate(plate)
    if vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
        local coords = GetEntityCoords(vehicle)
        local heading = GetEntityHeading(vehicle)
        updatePlateVehicleState(plate, { x = coords.x, y = coords.y, z = coords.z }, heading, getNetIdFromEntitySafe(vehicle))
        return vector3(coords.x, coords.y, coords.z)
    end

    local plateState = PlateLabStates[plate]
    if plateState and plateState.currentCoords then
        return vector3(plateState.currentCoords.x, plateState.currentCoords.y, plateState.currentCoords.z)
    end

    return nil
end)

local function getVehicleExitPosition(vehicle)
    local coords = GetEntityCoords(vehicle)
    local heading = GetEntityHeading(vehicle)
    local rad = math.rad(heading)
    local offsetX = math.sin(rad) * 3.5
    local offsetY = -math.cos(rad) * 3.5
    return vector3(coords.x + offsetX, coords.y + offsetY, coords.z), heading
end

local function bucketFromPlate(plate)
    plate = trimPlate(plate):upper()
    local hash = 0
    for i = 1, #plate do hash = (hash * 33 + plate:byte(i)) % 1000000 end
    return 4000 + hash
end

local function getOrCreatePlateState(plate)
    plate = trimPlate(plate)
    if plate == '' then return nil end
    PlateLabStates[plate] = PlateLabStates[plate] or { plate = plate, occupants = {}, occupantCount = 0, currentCoords = nil, currentHeading = nil, shellAnchorCoords = nil, vehicleNetId = nil }
    return PlateLabStates[plate]
end

local function setVehicleOccupiedStateByPlate(plate, occupied)
    local vehicle = findVehicleByPlate(plate)
    if vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
        Entity(vehicle).state:set('vgDrugLabOccupied', occupied and true or false, true)
        Entity(vehicle).state:set('vgDrugLabPlate', trimPlate(plate), true)
    end
end

local function syncPlateOccupancyState(plate)
    local plateState = PlateLabStates[trimPlate(plate)]
    local occupied = plateState and (plateState.occupantCount or 0) > 0 or false
    setVehicleOccupiedStateByPlate(plate, occupied)
    return occupied
end

local function addOccupantToPlateState(src, state)
    if not state or not state.plate then return nil end
    local plateState = getOrCreatePlateState(state.plate)
    if not plateState.occupants[src] then
        plateState.occupants[src] = true
        plateState.occupantCount = (plateState.occupantCount or 0) + 1
    end
    if state.lastCoords then plateState.currentCoords = vector3(state.lastCoords.x, state.lastCoords.y, state.lastCoords.z) end
    if state.lastHeading then plateState.currentHeading = state.lastHeading end
    if not plateState.shellAnchorCoords and state.lastCoords then
        plateState.shellAnchorCoords = { x = state.lastCoords.x, y = state.lastCoords.y, z = state.lastCoords.z }
    end
    if state.vehicleNetId and state.vehicleNetId ~= 0 then plateState.vehicleNetId = state.vehicleNetId end
    syncPlateOccupancyState(state.plate)
    return plateState
end

local function removeOccupantFromPlateState(src, plate)
    plate = trimPlate(plate)
    local plateState = PlateLabStates[plate]
    if not plateState then return end
    if plateState.occupants[src] then
        plateState.occupants[src] = nil
        plateState.occupantCount = math.max((plateState.occupantCount or 1) - 1, 0)
    end
    if plateState.occupantCount <= 0 then
        PlateLabStates[plate] = nil
        syncPlateOccupancyState(plate)
        return
    end
    syncPlateOccupancyState(plate)
end

updatePlateVehicleState = function(plate, coords, heading, vehicleNetId)
    plate = trimPlate(plate)
    local plateState = getOrCreatePlateState(plate)
    if coords then
        plateState.currentCoords = vector3(coords.x, coords.y, coords.z)
        if not plateState.shellAnchorCoords then plateState.shellAnchorCoords = { x = coords.x, y = coords.y, z = coords.z } end
    end
    if heading then plateState.currentHeading = heading end
    if vehicleNetId and vehicleNetId ~= 0 then plateState.vehicleNetId = vehicleNetId end
    syncPlateOccupancyState(plate)
    return plateState
end

local function isPlateOccupied(plate)
    local plateState = PlateLabStates[trimPlate(plate)]
    return plateState and (plateState.occupantCount or 0) > 0 or false
end

local function getPlayersInLab(plate)
    local players = {}
    local plateState = PlateLabStates[trimPlate(plate)]
    if not plateState then return players end
    for src, _ in pairs(plateState.occupants or {}) do if ActiveLabs[src] then players[#players + 1] = src end end
    return players
end

local function cleanupLabDatabase(plate)
    plate = trimPlate(plate)
    if plate == '' then return end
    exports.oxmysql:query('DELETE FROM vg_drug_lab_vehicles WHERE plate = ?', { plate })
    exports.oxmysql:query('DELETE FROM vg_drug_lab_props_v2 WHERE plate = ?', { plate })
    exports.oxmysql:query('DELETE FROM vg_drug_lab_props WHERE plate = ?', { plate }, function() end)
end

local function destroyLabByPlate(plate)
    plate = trimPlate(plate)
    if plate == '' then return false end
    local vehicle = findVehicleByPlate(plate)
    local plateState = PlateLabStates[plate]
    local blastCoords, exitCoords, exitHeading
    if vehicle and DoesEntityExist(vehicle) then
        local vehicleCoords = GetEntityCoords(vehicle)
        blastCoords = vector3(vehicleCoords.x, vehicleCoords.y, vehicleCoords.z)
        exitCoords, exitHeading = getVehicleExitPosition(vehicle)
    elseif plateState and plateState.currentCoords then
        blastCoords = vector3(plateState.currentCoords.x, plateState.currentCoords.y, plateState.currentCoords.z)
        exitCoords = blastCoords
        exitHeading = plateState.currentHeading or 0.0
    else
        return false
    end

    for _, target in ipairs(getPlayersInLab(plate)) do
        local state = ActiveLabs[target]
        if state then
            SetPlayerRoutingBucket(target, state.lastBucket or 0)
            TriggerClientEvent('vg-drugs:client:ForceExitLab', target, exitCoords, exitHeading or 0.0)
            ActiveLabs[target] = nil
        end
    end

    TriggerClientEvent('vg-drugs:client:ExplodeVehicleAtCoords', -1, { x = blastCoords.x + 0.0, y = blastCoords.y + 0.0, z = blastCoords.z + 0.0 })

    if vehicle and DoesEntityExist(vehicle) then
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteEntity(vehicle)
    end

    cleanupLabDatabase(plate)
    VehicleLabs[plate] = nil
    PlateLabStates[plate] = nil
    return true
end

CreateThread(function()
    while true do
        Wait(1000)
        local vehicles = getAllVehiclesSafe()
        for i = 1, #vehicles do
            local veh = vehicles[i]
            if veh and veh ~= 0 and DoesEntityExist(veh) then
                local plate = trimPlate(GetVehicleNumberPlateText(veh))
                local labType = VehicleLabs[plate]
                if labType and Entity(veh).state.drugLabType ~= labType then Entity(veh).state:set('drugLabType', labType, true) end
            end
        end

        for plate, plateState in pairs(PlateLabStates) do
            local vehicle = findVehicleByPlate(plate)
            if vehicle and DoesEntityExist(vehicle) then
                local coords = GetEntityCoords(vehicle)
                local heading = GetEntityHeading(vehicle)
                local netId = getNetIdFromEntitySafe(vehicle)
                updatePlateVehicleState(plate, { x = coords.x, y = coords.y, z = coords.z }, heading, netId)
                for src, _ in pairs(plateState.occupants or {}) do
                    local state = ActiveLabs[src]
                    if state then
                        state.plate = plate
                        state.lastCoords = { x = coords.x, y = coords.y, z = coords.z }
                        state.lastHeading = heading
                        if netId and netId ~= 0 then state.vehicleNetId = netId end
                    end
                end
            end
        end
    end
end)

CreateThread(function()
    Wait(1000)
    exports.oxmysql:query([[CREATE TABLE IF NOT EXISTS vg_drug_lab_props_v2 (
        id INT(11) NOT NULL AUTO_INCREMENT,
        plate VARCHAR(20) NOT NULL,
        model VARCHAR(100) NOT NULL,
        prop_type VARCHAR(50) NOT NULL,
        offset_coords LONGTEXT NOT NULL,
        heading_offset FLOAT NOT NULL DEFAULT 0,
        item_name VARCHAR(100) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (id),
        KEY idx_vg_drug_lab_props_v2_plate (plate)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci]], {}, function() end)

    exports.oxmysql:query([[CREATE TABLE IF NOT EXISTS vg_drug_lab_vehicles (
        plate VARCHAR(20) NOT NULL,
        lab_type VARCHAR(50) NOT NULL,
        updated_by VARCHAR(50) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (plate)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci]], {}, function() end)

    exports.oxmysql:query('SELECT plate, lab_type FROM vg_drug_lab_vehicles', {}, function(result)
        VehicleLabs = {}
        for _, row in ipairs(result or {}) do VehicleLabs[trimPlate(row.plate)] = (row.lab_type or 'meth'):lower() end
        print(('^2[VG-Drugs]^7 %s caravan lab record(s) loaded.'):format(#(result or {})))
    end)
end)

registerUsable(Config.Meth.Items.table, function(source) TriggerClientEvent('vg-drugs:client:UseMethTable', source) end)

local function setupCaravanLab(src, plate, vehicleNetId, labType)
    local cleanPlate = trimPlate(plate)
    labType = (labType or 'meth'):lower()
    if cleanPlate == '' then return notify(src, 'error', 'No valid plate could be found.') end
    if VehicleLabs[cleanPlate] then return notify(src, 'error', 'A laboratory is already installed in this caravan!') end
    local ok, missingItem, missingCount = hasSetupItems(src)
    if not ok then return notify(src, 'error', ('Setup requires %sx %s.'):format(missingCount or 1, missingItem or 'item')) end

    consumeSetupItems(src)
    VehicleLabs[cleanPlate] = labType

    local vehicle = getEntityFromNetIdSafe(vehicleNetId)
    if vehicle and vehicle ~= 0 then
        Entity(vehicle).state:set('drugLabType', labType, true)
        Entity(vehicle).state:set('vgDrugLabPlate', cleanPlate, true)
    end

    local _, player = getPlayerObject(src)
    exports.oxmysql:update('INSERT INTO vg_drug_lab_vehicles (plate, lab_type, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE lab_type = VALUES(lab_type), updated_by = VALUES(updated_by)', { cleanPlate, labType, getPlayerIdentifier(src) })
    notify(src, 'success', cleanPlate .. ' caravan set as Meth Lab (Acid Interior)!')
end

RegisterNetEvent('vg-drugs:server:SetupCaravanLab', function(plate, vehicleNetId) setupCaravanLab(source, plate, vehicleNetId, 'meth') end)
RegisterNetEvent('vg-drugs:server:SetupCaravanLabFromNpc', function(plate, vehicleNetId, labType) setupCaravanLab(source, plate, vehicleNetId, labType or 'meth') end)

RegisterNetEvent('vg-drugs:server:EnterActiveDrugLab', function(vehicleNetId)
    local src = source
    local ped = GetPlayerPed(src)
    local playerCoords = GetEntityCoords(ped)
    local vehicle = resolveVehicle(vehicleNetId, nil, { x = playerCoords.x, y = playerCoords.y, z = playerCoords.z })
    if not vehicle or not DoesEntityExist(vehicle) then return notify(src, 'error', 'Caravan not found.') end
    if #(playerCoords - GetEntityCoords(vehicle)) > 8.0 then return notify(src, 'error', 'You are too far away from the caravan.') end

    local vehicleCoords = GetEntityCoords(vehicle)
    local plate = trimPlate(GetVehicleNumberPlateText(vehicle))
    local labType = VehicleLabs[plate]
    if not labType then return notify(src, 'error', 'Bu karavanda kurulu laboratuvar yok.') end

    local bucket = bucketFromPlate(plate)
    local netId = getNetIdFromEntitySafe(vehicle)

    ActiveLabs[src] = { bucket = bucket, vehicleNetId = netId, plate = plate, labType = labType, returnHeading = GetEntityHeading(vehicle), lastBucket = GetPlayerRoutingBucket(src), lastCoords = { x = vehicleCoords.x, y = vehicleCoords.y, z = vehicleCoords.z }, lastHeading = GetEntityHeading(vehicle) }

    local plateState = addOccupantToPlateState(src, ActiveLabs[src])
    updatePlateVehicleState(plate, { x = vehicleCoords.x, y = vehicleCoords.y, z = vehicleCoords.z }, GetEntityHeading(vehicle), netId)
    local shellCoords = (plateState and plateState.shellAnchorCoords) or { x = vehicleCoords.x, y = vehicleCoords.y, z = vehicleCoords.z }

    SetPlayerRoutingBucket(src, bucket)
    TriggerClientEvent('vg-drugs:client:EnterDrugLab', src, { labType = labType, vehicleNetId = netId, plate = plate, bucket = bucket, coords = { x = vehicleCoords.x, y = vehicleCoords.y, z = vehicleCoords.z }, shellCoords = shellCoords })
end)

RegisterNetEvent('vg-drugs:server:ExitActiveDrugLab', function()
    local src = source
    local state = ActiveLabs[src]

    if not state then
        SetPlayerRoutingBucket(src, 0)
        TriggerClientEvent('vg-drugs:client:ForceExitLab', src, vec3(2326.98, 2573.72, 46.67), 0.0)
        return
    end

    local exitCoords, exitHeading
    local plateState = PlateLabStates[state.plate]
    local vehicle = getStateVehicle(state)

    if vehicle and vehicle ~= 0 and DoesEntityExist(vehicle) then
        local speed = GetEntitySpeed(vehicle) * 3.6
        if speed > 5.0 then
            TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'You cannot exit while the caravan is moving!' })
            return
        end
    end

    if vehicle and vehicle ~= 0 then
        exitCoords, exitHeading = getVehicleExitPosition(vehicle)
        local vehicleCoords = GetEntityCoords(vehicle)
        updatePlateVehicleState(state.plate, { x = vehicleCoords.x, y = vehicleCoords.y, z = vehicleCoords.z }, GetEntityHeading(vehicle), getNetIdFromEntitySafe(vehicle))
    elseif plateState and plateState.currentCoords then
        exitCoords = vector3(plateState.currentCoords.x, plateState.currentCoords.y, plateState.currentCoords.z)
        exitHeading = plateState.currentHeading or state.lastHeading or state.returnHeading or 0.0
    elseif state.lastCoords then
        exitCoords = vector3(state.lastCoords.x, state.lastCoords.y, state.lastCoords.z)
        exitHeading = state.lastHeading or state.returnHeading or 0.0
    else
        exitCoords = GetEntityCoords(GetPlayerPed(src))
        exitHeading = GetEntityHeading(GetPlayerPed(src))
    end

    SetPlayerRoutingBucket(src, state.lastBucket or 0)
    TriggerClientEvent('vg-drugs:client:ExitDrugLab', src, exitCoords, exitHeading or 0.0)
    ActiveLabs[src] = nil
    removeOccupantFromPlateState(src, state.plate)
end)

RegisterNetEvent('vg-drugs:server:OpenActiveLabStash', function()
    local src = source
    local state = ActiveLabs[src]
    if not state then return end
    local stashId = ('druglab_%s'):format(state.plate)
    local stashLabel = ('%s %s'):format(state.labType == 'meth' and 'Meth' or 'Coke', state.plate)
    exports.ox_inventory:RegisterStash(stashId, stashLabel, 120, 250000, false)
    TriggerClientEvent('vg-drugs:client:OpenLabStash', src, stashId, stashLabel)
end)

RegisterNetEvent('vg-drugs:server:SyncLabVehiclePosition', function()
    local src = source
    local state = ActiveLabs[src]
    if not state then return end
    local vehicle = getStateVehicle(state)
    if not vehicle or vehicle == 0 then return end
    local coords = GetEntityCoords(vehicle)
    local heading = GetEntityHeading(vehicle)
    local vehicleNetId = getNetIdFromEntitySafe(vehicle)
    if vehicleNetId ~= 0 then state.vehicleNetId = vehicleNetId end
    updatePlateVehicleState(state.plate, { x = coords.x, y = coords.y, z = coords.z }, heading, state.vehicleNetId)

    for _, target in ipairs(getPlayersInLab(state.plate)) do
        local targetState = ActiveLabs[target]
        if targetState then
            targetState.lastCoords = { x = coords.x, y = coords.y, z = coords.z }
            targetState.lastHeading = heading
            if state.vehicleNetId then targetState.vehicleNetId = state.vehicleNetId end
        end
        TriggerClientEvent('vg-drugs:client:LabVehiclePosition', target, { plate = state.plate, coords = { x = coords.x, y = coords.y, z = coords.z }, heading = heading, vehicleNetId = state.vehicleNetId })
    end
end)

lib.callback.register('vg-drugs:server:CanStoreLabVehicle', function(source, vehicleNetId, plate)
    local vehicle = resolveVehicle(vehicleNetId, plate, nil)
    local resolvedPlate = plate
    if vehicle and vehicle ~= 0 then resolvedPlate = trimPlate(GetVehicleNumberPlateText(vehicle)) end
    if not resolvedPlate or resolvedPlate == '' then return true end
    if isPlateOccupied(resolvedPlate) then return false, 'You cannot store the vehicle while someone is inside the caravan.' end
    return true
end)

AddEventHandler('playerDropped', function()
    local src = source
    local state = ActiveLabs[src]
    if state then
        ActiveLabs[src] = nil
        removeOccupantFromPlateState(src, state.plate)
    end
end)

RegisterNetEvent('vg-drugs:server:MethAction', function(action, payload)
    local src = source
    local state = ActiveLabs[src]
    payload = payload or {}

    if action == 'cook_batch' then
        local rawItem = Config.Meth.Items.raw
        local amount = math.max(1, math.floor(tonumber(payload.amount) or 1))
        local quality = math.max(0, math.min(100, math.floor(tonumber(payload.quality) or 70)))

        local haveSacid = exports.ox_inventory:GetItem(src, Config.Meth.Items.sacid, nil, true) or 0
        local haveLithium = exports.ox_inventory:GetItem(src, Config.Meth.Items.lithium, nil, true) or 0
        local haveHcacid = exports.ox_inventory:GetItem(src, Config.Meth.Items.hcacid, nil, true) or 0
        local haveAmmonia = exports.ox_inventory:GetItem(src, Config.Meth.Items.ammonia, nil, true) or 0

        if haveSacid < amount or haveLithium < amount or haveHcacid < amount or haveAmmonia < amount then
            return notify(src, 'error', 'Not enough chemical materials. Sulfuric acid, lithium, hydrochloric acid, and ammonia are all required.')
        end

        exports.ox_inventory:RemoveItem(src, Config.Meth.Items.sacid, amount)
        exports.ox_inventory:RemoveItem(src, Config.Meth.Items.lithium, amount)
        exports.ox_inventory:RemoveItem(src, Config.Meth.Items.hcacid, amount)
        exports.ox_inventory:RemoveItem(src, Config.Meth.Items.ammonia, amount)

        local bonus = 0
        if quality >= 92 then bonus = math.floor(amount * 0.25)
        elseif quality >= 82 then bonus = math.floor(amount * 0.10)
        elseif quality <= 55 then bonus = -math.floor(amount * 0.10) end

        local output = math.max(1, amount + bonus)
        exports.ox_inventory:AddItem(src, rawItem, output)
        return notify(src, 'success', ('%sx materials processed, %sx raw meth produced. Quality: %s'):format(amount, output, quality))
    end

if action == 'pack_batch' then
        local rawItem = Config.Meth.Items.raw
        local bagItem = Config.Meth.Items.bag
        local packedItem = Config.Meth.Items.packed
        local kiloItem = 'water'

        local amount = math.max(1, math.floor(tonumber(payload.amount) or 1))
        local size = payload.size or '10g'

        local haveRaw = exports.ox_inventory:GetItem(src, rawItem, nil, true) or 0
        local haveBag = exports.ox_inventory:GetItem(src, bagItem, nil, true) or 0

        if haveRaw < amount then return notify(src, 'error', 'Not enough raw product.') end

        if size == '10g' then
            if haveBag < amount then return notify(src, 'error', 'You do not have enough empty bags.') end
            exports.ox_inventory:RemoveItem(src, rawItem, amount)
            exports.ox_inventory:RemoveItem(src, bagItem, amount)
            exports.ox_inventory:AddItem(src, packedItem, amount)
            return notify(src, 'success', ('%sx meth was weighed and packed for street sale.'):format(amount))
        elseif size == '1kg' then
            if amount < 10 then return notify(src, 'error', 'You need at least 10 raw units to make 1 kilogram.') end
            local producedKilos = math.floor(amount / 10)
            local usedRaw = producedKilos * 10

            exports.ox_inventory:RemoveItem(src, rawItem, usedRaw)
            exports.ox_inventory:AddItem(src, kiloItem, producedKilos)
            return notify(src, 'success', ('You prepared %sx 1 kilogram meth brick(s).'):format(producedKilos))
        end
    end

    if action == 'fail_poison' then
        TriggerClientEvent('vg-drugs:client:PoisonGas', src)
        sendConfiguredDispatch(src, getBestLabDispatchCoords(src), Config.Dispatch and Config.Dispatch.codes and Config.Dispatch.codes.poison or 'druglab', 'Chemical gas alarm in meth caravan')
        return notify(src, 'error', 'The process failed and chemical gas spread!')
    end

    if action == 'fail_explosion' then
        local plate = trimPlate((payload and payload.plate) or (state and state.plate) or '')
        local dispatchCoords = getBestLabDispatchCoords(src)
        sendConfiguredDispatch(src, dispatchCoords, Config.Dispatch and Config.Dispatch.codes and Config.Dispatch.codes.explosion or '10-80', 'Explosion alarm in meth caravan')
        if plate ~= '' then
            destroyLabByPlate(plate)
        else
            TriggerClientEvent('vg-drugs:client:ExplodeVehicleAtCoords', -1, { x = dispatchCoords.x + 0.0, y = dispatchCoords.y + 0.0, z = dispatchCoords.z + 0.0 })
        end
        return notify(src, 'error', 'The mixture went out of control and the caravan exploded!')
    end
end)
