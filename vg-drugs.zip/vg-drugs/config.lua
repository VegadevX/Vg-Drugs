Config = {}

-- Framework selector. Use 'auto', 'qb', 'qbx', 'esx', or 'standalone'.
Config.Framework = 'auto'

-- Locale selector. Available by default: 'en', 'tr', 'es', 'fr'. Missing keys fall back to English.
Config.Locale = 'en'

-- Target selector. Use 'auto', 'ox_target', or 'qb-target'. Auto uses ox_target first, then qb-target.
Config.Target = 'auto'

-- Default target interaction distance used by qb-target compatibility wrappers.
Config.TargetDistance = 2.0

-- Inventory selector. Use 'auto', 'ox_inventory', 'qb-inventory', 'ps-inventory', 'lj-inventory', 'qs-inventory'.
Config.Inventory = 'auto'


-- Batch production amount limits. These values control the minimum and maximum amount
-- a player can produce in a single action. The client input uses these limits and
-- the server validates them again to prevent menu/exploit abuse.
Config.BatchProduction = {
    weed_pack = { min = 1, max = 25 }, -- Weed table: raw weed + empty bag -> weed pack.
    weed_joint = { min = 1, max = 25 }, -- Weed table: raw weed -> joint.
    coke_process = { min = 1, max = 25 }, -- Coke table: coca leaf -> raw coke.
    coke_pack = { min = 1, max = 25 }, -- Coke table: raw coke + empty bag -> cocaine pack.
    meth_cook = { min = 1, max = 20 }, -- Meth lab: chemicals -> raw meth tray.
    meth_pack_10g = { min = 1, max = 25 }, -- Meth lab: raw meth + empty bag -> street-sale pack.
    meth_pack_1kg = { min = 10, max = 100 } -- Meth lab: raw meth units -> kilogram bricks. Min should usually match RawToKilo.
}

-- UI options for the built-in NUI mini-games and status panels.
Config.UI = {
    -- Visual theme name used by the NUI.
    theme = 'modern-dark'
}

-- NPC selling configuration: controls street-sale cooldowns, dispatch chance, money item, and sellable products.
Config.NPC = {
    MoneyItem = 'cash',
    Cooldown = 30,
    DispatchChance = 35,

    SellableDrugs = {
        ['coke_pack'] = { label = 'Cocaine Pack', minPrice = 150, maxPrice = 250, icon = 'pills' },
        ['meth_pack'] = { label = 'Meth Pack', minPrice = 100, maxPrice = 180, icon = 'cubes' },
        ['weed_pack'] = { label = 'Weed Pack', minPrice = 200, maxPrice = 350, icon = 'cannabis' },
        ['weed_joint'] = { label = 'Joint', minPrice = 200, maxPrice = 350, icon = 'cannabis' }
    }
}

-- Supplier shops: each shop has a ped, coords, and purchasable items.
Config.DrugShops = {
    Meth = {
        pedModel = 'g_m_m_chigoon_01',
        coords = vector4(3601.39, 3702.28, 36.64, 62.67),
        items = {
            { item = 'meth_sacid', label = 'Sulfuric Acid', price = 50 },
            { item = 'meth_lithium', label = 'Lithium', price = 50 },
            { item = 'meth_hcacid', label = 'Hydrochloric Acid', price = 50 },
            { item = 'meth_ammonia', label = 'Ammonia', price = 50 },
            { item = 'meth_table', label = 'Meth Table', price = 500 },
            { item = 'empty_bag', label = 'Empty Bag', price = 5 }
        }
    },

    Coke = {
        pedModel = 'g_m_y_salvagoon_01',
        coords = vector4(1343.57, 4383.04, 44.34, 260.83),
        items = {
            { item = 'coke_shear', label = 'Scissors', price = 25 },
            { item = 'empty_bag', label = 'Empty Bag', price = 5 },
            { item = 'coke_table', label = 'Cocaine Table', price = 500 },
            { item = 'coke_chemical', label = 'Cocaine Chemical', price = 50 }

        }
    },

    Weed = {
        pedModel = 'g_m_y_famca_01',
        coords = vector4(2195.83, 5593.42, 53.77, 12.02),
        items = {
            { item = 'weed_seed', label = 'Weed Seed', price = 100 },
            { item = 'empty_pot', label = 'Empty Pot', price = 50 },
            { item = 'fertilizer', label = 'Fertilizer', price = 30 },
            { item = 'grow_light', label = 'Grow Light', price = 200 },
            { item = 'empty_bag', label = 'Empty Bag', price = 5 },
            { item = 'weed_table', label = 'Weed Table', price = 500 }
        }
    }
}

-- Weed gameplay settings: items, props, processing requirements, placement rules, timers, chances, and yields.
Config.Weed = {
    Items = {
        seed = 'weed_seed',
        water = 'water',
        fertilizer = 'fertilizer',
        pot = 'empty_pot',
        light = 'grow_light',
        table = 'weed_table',
        raw = 'weed_raw',
        bag = 'empty_bag',
        packed = 'weed_pack',
        joint = 'weed_joint'
    },

    Props = {
        pot = 'bkr_prop_weed_01_small_01b',
        stage1 = 'bkr_prop_weed_01_small_01b',
        stage2 = 'bkr_prop_weed_med_01a',
        stage3 = 'bkr_prop_weed_lrg_01b',
        light = 'prop_worklight_04a',
        table = 'bkr_prop_weed_table_01a'
    },

    Processing = {
        PackRawRequired = 2, -- Amount of raw weed required to make 1 Weed Pack
        JointRawRequired = 2, -- Amount of raw weed required to make 1 Joint
    },

    Placement = {
        maxDistance = 5.0,
        surfaceSnap = 0.02,
        tableSnapExtra = 0.01,
        minClearance = 0.65
    },

    Times = {
        growthTime = 3,
        lightBoost = 2.0,
        waterDepletion = 50,
        plantSeed = 5000,
        waterPlant = 3000,
        placeLight = 4000,
        harvest = 8000,
        placeTable = 5000,
        processWeed = 10000
    },

    Chances = {
        extraYield = 30,
        returnSeed = 50,
        failProcess = 5
    },

    Yield = { min = 2, max = 5 },

    Growth = {
        UseTestTime = true,
        NormalSeconds = 4 * 60 * 60,
        LightSeconds = 2.5 * 60 * 60,
        TestNormalSeconds = 180,
        TestLightSeconds = 90
    }
}

-- Coke gameplay settings: items, props, field spawning, processing requirements, timers, chances, and yields.
Config.Coke = {
    Items = {
        table = 'coke_table',
        raw = 'coke_pile',
        leaf = 'coke_leaf',
        chemical = 'coke_chemical',
        bag = 'empty_bag',
        packed = 'coke_pack',
        scissors = 'coke_shear'
    },

    Props = {
        bush = 'prop_plant_01a',
        table = 'bkr_prop_coke_table01a'
    },

    Processing = {
        LeafToRaw = 1, -- Amount of coca leaves required to make 1 Raw Coke (powder)
        RawToPack = 1, -- Amount of raw coke required to make 1 Cocaine Pack
    },

    Field = {
        center = vector3(641.31, 4318.49, 81.54),
        radius = 40.0,
        amount = 20
    },

    Times = {
        harvestLeaf = 5000,
        placeTable = 5000,
        processCoke = 15000
    },

    Chances = {
        extraLeaf = 20,
        chemicalBurn = 10
    },

    Yield = { min = 1, max = 3 },
}

-- Caravan lab settings: mobile lab vendor, required setup items, blip following, and lab type.
Config.CaravanLabs = {
    defaultType = 'meth',
    followBlip = true,
    useUploadedDruglabs = false,

    vendor = {
        ped = 's_m_m_autoshop_02',
        coords = vec4(2326.98, 2573.72, 46.67, 65.1),
        label = 'Lab Setup'
    },

    setupItems = {
        ['meth_table'] = 1,
        ['metalscrap'] = 15,
        ['glass'] = 5
    }
}

-- Meth lab settings: items, props, processing requirements, interior positions, timers, chances, and yields.
Config.Meth = {
    Items = {
        table = 'meth_table',
        sacid = 'meth_sacid',
        lithium = 'meth_lithium',
        hcacid = 'meth_hcacid',
        ammonia = 'meth_ammonia',
        raw = 'meth_tray2',
        bag = 'empty_bag',
        packed = 'meth_pack'
    },

    Props = {
        table = 'bkr_prop_meth_table_01a',
        camper = 'journey'
    },

    Processing = {
        RawToKilo = 10, -- Amount of raw meth required to make 1 Kilogram Meth Brick
    },

    Times = {
        placeTable = 6000,
        preheat = 5000,
        chemicalPour = 5000,
        cookMeth = 18000,
        breakCrystal = 7000,
        packMeth = 5000
    },

    Chances = {
        explosion = 15,
        highPurity = 25
    },

    Yield = { min = 3, max = 6 },

    Interior = {
        label = 'Meth Lab',
        spawn = vec4(482.22, -2623.80, -49.06, 180.04),
        exit = vec3(482.22, -2623.80, -49.06),
        cookStation = vec3(484.33, -2626.08, -49.06),
        chemStation = vec3(484.33, -2626.08, -49.06),
        breakStation = vec3(488.73, -2624.39, -48.66),
        stashStation = vec3(481.10, -2625.70, -48.66)
    }
}

-- Dispatch integration settings. Set enabled=false to disable police alerts.
Config.Dispatch = {
    enabled = true,
    provider = 'ps_dispatch',
    customEvent = '',
    jobs = { 'leo', 'police' },
    codes = {
        explosion = '10-80',
        poison = '10-80'
    }
}
-- Custom integration hooks for inventories or targets that are not listed above.
-- Set Config.Inventory = 'custom' and fill these functions if your server uses a private inventory.
-- Set Config.Target = 'custom' and fill these functions if your server uses a private target script.
Config.CustomInventory = {
    -- Server-side only. Must return the amount of an item owned by the player.
    GetItemCount = function(source, itemName) return 0 end,
    -- Server-side only. Must give an item to the player and return true/false.
    AddItem = function(source, itemName, amount, metadata) return false end,
    -- Server-side only. Must remove an item from the player and return true/false.
    RemoveItem = function(source, itemName, amount, metadata) return false end,
    -- Server-side only. Return true if the player can carry the item.
    CanCarry = function(source, itemName, amount) return true end,
}

Config.CustomTarget = {
    -- Client-side only. Replace these wrappers if you use a target resource other than ox_target/qb-target/qtarget.
    AddModel = function(models, options) end,
    AddLocalEntity = function(entity, options) end,
    RemoveLocalEntity = function(entity) end,
    AddGlobalPed = function(options) end,
    AddSphereZone = function(data) end,
    RemoveZone = function(zoneId) end,
}
